import p2.Packagep2Class;

public class MainApp extends Packagep2Class{

	public static void main(String[] args) {
		MyClass ob=new MyClass();
		//within package
		System.out.println("private data "+ob.dfaultval);
		System.out.println("public data "+ob.publicval);
		System.out.println("protected data "+ob.protetedval);
		
		
		//for another package
		MainApp mob=new MainApp();
		System.out.println(mob.publicp2val);
		System.out.println(mob.protectedp2val);
		Packagep2Class pob=new Packagep2Class();
		System.out.println(pob.publicp2val);
		
	}

}
