package accessp1;

public class MyClass {
    private int privateval;
    public int publicval;
    int dfaultval;//default
    protected int protetedval;
    
   public MyClass() {
	   privateval=10;
	   publicval=98;		
	   dfaultval=78;
	   protetedval=12;
	}
    
    public void method1() {
    	System.out.println("n="+privateval);
    }
}

