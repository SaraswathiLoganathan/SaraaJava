package com.one;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class AddressOneToOne {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	private int aid;
	private String addcross;
	private String addstreet;
	
	//@OneToOne
	//StudentOneToOne stob;
	
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public String getAddcross() {
		return addcross;
	}
	public void setAddcross(String addcross) {
		this.addcross = addcross;
	}
	public String getAddstreet() {
		return addstreet;
	}
	public void setAddstreet(String addstreet) {
		this.addstreet = addstreet;
	}
	
	
	

}
