package com.one;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;


public class MainOneToOne {

	public static void main(String[] args) {
		Configuration config =new Configuration().configure().addAnnotatedClass(StudentOneToOne.class).addAnnotatedClass(AddressOneToOne.class);
		ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(config.getProperties()).buildServiceRegistry();
	    SessionFactory sf=config.buildSessionFactory(reg);
	    Session session=sf.openSession();
	    Transaction tx=session.beginTransaction();
	    
	    AddressOneToOne aob=new AddressOneToOne();
	    StudentOneToOne sob=new StudentOneToOne();
	    
	    aob.setAddcross("Ranga Nagar");
	    aob.setAddstreet("Ram street");
	    
	    
	    
	    sob.setSname("Saraswathi");
	    sob.setSage(24);
	 sob.setAddr(aob);
	    session.save(sob);
	    session.save(aob);
	    tx.commit();
	}

}
