package com.one;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
@Entity
public class StudentOneToOne {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
	
private int sid;
	private String sname;
	private int sage;
	
	@OneToOne
	@JoinColumn(name="st_add")
	AddressOneToOne addr;
	
	
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public int getSage() {
		return sage;
	}
	public void setSage(int sage) {
		this.sage = sage;
	}
	public AddressOneToOne getAddr() {
		return addr;
	}
	public void setAddr(AddressOneToOne addr) {
		this.addr = addr;
	}
	
	
}
