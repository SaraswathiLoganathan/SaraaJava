package employeehiber;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class MainEmployees {
	Configuration config=new Configuration().configure().addAnnotatedClass(Employees.class);
	ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(config.getProperties()).buildServiceRegistry();
    SessionFactory sf=config.buildSessionFactory(reg);
    Session session=sf.openSession();
    Transaction tx=session.beginTransaction();

	Employees ob = new Employees();
	ob.setSid(1);
	ob.setSname("Saras");
	session.save(ob);
	tx.commit();
}
