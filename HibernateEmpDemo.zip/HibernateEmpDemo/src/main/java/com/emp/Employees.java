package com.emp;

@Entity
public class Employees {
@id
	private int EmployeeId;
	private String EmployeeName;
	private int EmployeeAge;
	public int getEmployeeId() {
		return EmployeeId;
	}
	public void setEmployeeId(int employeeId) {
		EmployeeId = employeeId;
	}
	public String getEmployeeName() {
		return EmployeeName;
	}
	public void setEmployeeName(String employeeName) {
		EmployeeName = employeeName;
	}
	public int getEmployeeAge() {
		return EmployeeAge;
	}
	public void setEmployeeAge(int employeeAge) {
		EmployeeAge = employeeAge;
	}
	public int getEmployeeSalary() {
		return EmployeeSalary;
	}
	public void setEmployeeSalary(int employeeSalary) {
		EmployeeSalary = employeeSalary;
	}
	public String getEmployeeDept() {
		return EmployeeDept;
	}
	public void setEmployeeDept(String employeeDept) {
		EmployeeDept = employeeDept;
	}
	private int EmployeeSalary;
	private String EmployeeDept;

}
