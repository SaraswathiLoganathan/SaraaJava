package hiber.employee;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;



@Entity
public class Employee {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY) 
private int eid;
private String ename;
@Column(name="empname",length = 40)
private int eage;
@Column(name="empage")
private float esalary;
@Column(name="empsalary")
private String edept;
@Column(name="empdept")

public String getEdept() {
	return edept;
}
public void setEdept(String edept) {
	this.edept = edept;
}
public int getEid() {
	return eid;
}
public void setEid(int eid) {
	this.eid = eid;
}
public String getEname() {
	return ename;
}
public void setEname(String ename) {
	this.ename = ename;
}
public int getEage() {
	return eage;
}
public void setEage(int eage) {
	this.eage = eage;
}
public float getEsalary() {
	return esalary;
}
public void setEsalary(float esalary) {
	this.esalary = esalary;
}
@Override
public String toString() {
	return "Employee [eid=" + eid + ", ename=" + ename + ", eage=" + eage + ", esalary=" + esalary + ", edept=" + edept
			+ "]";
}
}