package hiber.employee;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;




public class EmployeeMain {

	public static void main(String[] args) {
		Configuration config=new Configuration().configure().addAnnotatedClass(Employee.class);
		ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(config.getProperties()).buildServiceRegistry();
	    SessionFactory sf=config.buildSessionFactory(reg);
	    Session session=sf.openSession();
	    Transaction tx=session.beginTransaction();
	    
	   /* Employee e =new Employee();
	    e.setEid(1);
	    e.setEname("mani");
	   e.setEage(40);
	    e.setEsalary(20000);
	    e.setEdept("SCC");
	    session.save(e);
	    
	    Employee e1 =new Employee();
	    e1.setEid(2);
	    e1.setEname("saras");
	   e1.setEage(42);
	    e1.setEsalary(40000);
	    e1.setEdept("SQC");
	    session.save(e1);
	    
	    Employee e2 =new Employee();
	    e2.setEid(3);
	    e2.setEname("kalai");
	   e2.setEage(34);
	    e2.setEsalary(80000);
	    e2.setEdept("SSF");
	    session.save(e2);
	    
	    Employee e3 =new Employee();
	    e3.setEid(4);
	    e3.setEname("giri");
	   e3.setEage(46);
	    e3.setEsalary(70000);
	    e3.setEdept("SBC");
	    session.save(e3);
	    
	    Employee e4 =new Employee();
	    e4.setEid(5);
	    e4.setEname("priya");
	   e4.setEage(35);
	    e4.setEsalary(60000);
	    e4.setEdept("SCL");
	    session.save(e4);
	    tx.commit();*/

	    
	    //get record by id
	  /*  Employee eob=(Employee)session.get(Employee.class, 1);
	    System.out.println(eob);
	    
	    //fetch all records
	    
	    Query q=session.createQuery("from Employee");
	    List<Employee> lst=q.list();
	    
	    
	    //iterator
	    Iterator<Employee> it=lst.iterator();
	    System.out.println("Eid\tEname\tEage\tEsalary\tEdept");
	    while(it.hasNext()) {
	    	Employee eob1=it.next();
	    	System.out.println(eob1.getEid()+"\t"+eob1.getEname()+"\t"+eob1.getEage()+"\t"+eob1.getEsalary()+"\t"+eob1.getEdept());
	   */
	  /* Query q1=session.createQuery("update Employee set ename=:n where eid=:i");
			q1.setParameter("i", 1);
			   q1.setParameter("n", "AAA");
			int i=q1.executeUpdate();
			if(i>0) {
				System.out.println("Record is updated");
			}
			else {
				 System.out.println("Not updated");
			}*/
	    	
	    	Query d=session.createQuery("delete from Employee where eid=:i");
			d.setParameter("i", 6);
			int i=d.executeUpdate();
			if(i>0) {
				System.out.println("Record is deleted");
			}
			else {
				 System.out.println("Not deleted");
			}

			tx.commit();
	    }
	    
	    
	}
    
	   
	


