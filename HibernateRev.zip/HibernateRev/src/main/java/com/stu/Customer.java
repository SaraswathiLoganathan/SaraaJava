package com.stu;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
@Entity
public class Customer {
@GeneratedValue(strategy = GenerationType.IDENTITY)
@Id
	private int Cid;
	private String Cname;
	
	@OneToOne
	private Product pt;
	
	public int getCid() {
		return Cid;
	}
	public void setCid(int cid) {
		Cid = cid;
	}
	public String getCname() {
		return Cname;
	}
	public void setCname(String cname) {
		Cname = cname;
	}
	public Product getPt() {
		return pt;
	}
	public void setPt(Product pt) {
		this.pt = pt;
	}
	
	
	
}
