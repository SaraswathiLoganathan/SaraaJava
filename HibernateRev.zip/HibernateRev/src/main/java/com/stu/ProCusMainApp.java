package com.stu;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;


public class ProCusMainApp {

	public static void main(String[] args) {
		
		Product pob = new Product();
	    pob.setPname("Biscut");
	    
	    
	    Customer cob =new Customer();
	    cob.setCname("Kiran");
	    cob.setPt(pob);
		
		Configuration config =new Configuration().configure().addAnnotatedClass(Product.class).addAnnotatedClass(Customer.class);
		ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(config.getProperties()).buildServiceRegistry();
	    SessionFactory sf=config.buildSessionFactory(reg);
	    Session session=sf.openSession();
	    Transaction tx=session.beginTransaction();
	    
	    session.save(cob);
	    session.save(pob);
	    tx.commit();
	}

}
