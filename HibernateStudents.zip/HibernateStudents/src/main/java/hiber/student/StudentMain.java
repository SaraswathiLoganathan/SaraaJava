package hiber.student;


import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class StudentMain {

	public static void main(String[] args) {
		Configuration config=new Configuration().configure().addAnnotatedClass(Student.class);
		ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(config.getProperties()).buildServiceRegistry();
	    SessionFactory sf=config.buildSessionFactory(reg);
	    Session session=sf.openSession();
	    Transaction tx=session.beginTransaction();
	  
	    Student ob=new Student();//transient state
	    
	  /*  ob.setSid(11);
	    ob.setSname("saraa");
	    session.save(ob);//insert 
	    tx.commit();*/
	    
	    
	    /*ob.setSid(17);
	    	ob.setSname("deli");
	    	session.save(ob);
	    	session.delete(ob);
	    	tx.commit();*/
	    
	    
	   /* ob.setSid(21);
    	ob.setSname("mani");
    	session.save(ob);
    	tx.commit();
    	session.evict(ob);//object is detached from database using evict
    	ob.setSname("fathima");
    	*/
	    
	    //detached state
	    
	    //remove state
	    
	 /*   ob.setSname("ravi");
	    session.save(ob);//persistent
	    session.delete(ob);
	    System.out.println(ob);
	    //remove state
	    tx.commit();*/
	    
	/*    
	    Student ob1=(Student) session.get(Student.class, 11);//select * from student where sid=1;
	    System.out.println("Name="+ob1.getSname());
	    
	    //all the records
	    Query q=session.createQuery("from Student");//return all the records
	    List l=q.list();
	    
	    //iterate arrayList
	    Iterator<Student> lst=l.iterator();
	    while(lst.hasNext()) {
	    	Student s=lst.next();
	    	System.out.println(s.getSid()+"  "+s.getSname());
	    */	
//update record change name
	    
	  /*Query q=session.createQuery("update Student set sname=:n where sid=:i");
		q.setParameter("n", "Poonam");
		q.setParameter("i", 11);
		
		int i=q.executeUpdate();
		if(i>0) {
			System.out.println("Record is updated");
		}
		else {
			 System.out.println("Not updated");
		}*/
	  
//delete record
	    
	    Query d=session.createQuery("delete from Student where sid=:i");
		d.setParameter("i", 15);
	int i=d.executeUpdate();
	if(i>0) {
		System.out.println("Record is deleted");
	}
	else {
		 System.out.println("Not deleted");
		}
	}
}



