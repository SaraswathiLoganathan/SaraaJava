package com.edu;

public class Body {
@auto
Heart heart;
	public void humanBody() {
		System.out.println("Human body method");
		if(heart!=null) {
			heart.heartFun();
		}else {
			System.out.println("Heart is not functioning");
		}
	}
}
