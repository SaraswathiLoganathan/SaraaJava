package com.edu;

public class Heart {
public void heartFun() {
	System.out.println("Heart is functioning");
}
}
