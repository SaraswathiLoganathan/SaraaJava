package com.edu;

import org.springframework.beans.factory.annotation.Autowired;

public class Body {
	@Autowired
	Heart heart;
	public void humanBody() {
		System.out.println("Human Body Method");
		if(heart!=null) {
			heart.heartFun();
		}else {
			System.out.println("Heart is not functioning");
		}
	}

}
