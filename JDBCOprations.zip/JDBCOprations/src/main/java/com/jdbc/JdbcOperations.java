package com.jdbc;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class JdbcOperations {
private static Connection myconn; 
private static Statement st;
private static ResultSet rs;
public static void displayStudents() throws SQLException {
	myconn=DatabaseConnection.getConnection();
	st=myconn.createStatement();
	String sel="select * from students";
	rs=st.executeQuery(sel);
	
	System.out.println("sid\tsname\tcid\tsdate\tfees");
	  
	  while(rs.next()) {
		  int sn=rs.getInt(1);// or rs.getInt("sid");
		  String sname=rs.getString(2);//or rs.getString("sname");
		  int cid=rs.getInt(3); //or rs.getInt("cid");
		  String sd=rs.getString(4);
		  float fs=rs.getFloat(5); //rs.getFloat("fees");
		  System.out.println(sn+"\t"+sname+"\t"+cid+"\t"+sd+"\t"+fs);
	  }
}

public static void addStudents() throws SQLException {
	myconn=DatabaseConnection.getConnection();
	st=myconn.createStatement();
	
	int id,cid;
	String sn,sd;
	float fs;
	Scanner sc=new Scanner(System.in);
	
	System.out.println("Enter student name");
	sn=sc.next();
	System.out.println("Enter Student id");
	id=sc.nextInt();
	System.out.println("Enter student fees");
	fs=sc.nextFloat();
	System.out.println("Enter student DOB");
	sd=sc.next();
	System.out.println("Enter cid");
	cid=sc.nextInt();
	
	//check record exists
	String sel="select * from students where sid="+id;
	rs=st.executeQuery(sel);
	if(rs.next()){
		System.out.println(id+" already exists");
	}else {
		
	String ins="insert into students values("+id+",'"+sn+"',"+cid+",'"+sd+"',"+fs+");";
	System.out.println(ins);
	int rval=st.executeUpdate(ins);//for insert , update and delete use exceuteUpdate
	if(rval>0) {
		System.out.println("Record is added");
	}
	else {
		System.out.println("Error Occurred");
	}
	}
}
public static void deleteStudents() throws SQLException {
	myconn=DatabaseConnection.getConnection();
	st=myconn.createStatement();
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter sid to delete record");
	int stdid=sc.nextInt();
  String sel="select * from students where sid="+stdid;
  rs=st.executeQuery(sel);
  if(rs.next()) { 
	  
	  //if this statement is true means record exists
	  String del="delete from students where sid="+stdid;
	  int retval=st.executeUpdate(del);
	  if(retval>0) {
		  System.out.println("Record is deleted");
	  }else {
		  System.out.println("Error!!!! occurred");
	  }
  }else {
	  System.out.println(stdid+" not exixts");
  }
	
}

public static void updateStudents() throws SQLException {
	myconn=DatabaseConnection.getConnection();
	st=myconn.createStatement();
	
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter name to be changed");
	String n=sc.next();
	System.out.println("Enter student id");
	int stid=sc.nextInt();
	
	//check id exists for updating record
	
	String sel="select * from students where sid="+stid;
	rs=st.executeQuery(sel);
	if(rs.next()) { //update
		String upd="update students set sname='"+n+"' where sid="+stid;
		int retval=st.executeUpdate(upd);
		if(retval>0) {
			System.out.println("Student changed successfully");
		}else {
			System.out.println("Error!!!!");
		}
	}else {
		System.out.println(stid+" not exists for updating record");
	}
	
}
	
}