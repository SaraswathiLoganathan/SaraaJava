package com.jdbc;
import java.sql.SQLException;
import java.util.Scanner;

public class MainJDBCOperations {

	public static void main(String[] args) throws SQLException {
		Scanner sc=new Scanner(System.in);
		int choice;
		char ch;
		while(true) {
		System.out.println("*********MENU***************");
		System.out.println("Database operations");
		System.out.println("Enter your choice");
		System.out.println("1.Display Students");
		System.out.println("2.Add Students");
		System.out.println("3.Delete Student based on student id");
		System.out.println("4.update student");
		
		choice=sc.nextInt();
		switch(choice) {
		case 1: //display
			    System.out.println("display all students");
			    JdbcOperations.displayStudents();
			    
			    break;
		case 2: //add students
			     System.out.println("Add new student");
			     JdbcOperations.addStudents();
			    break;
		case 3: //delete based on id
			      System.out.println("delete student based on id");
			      JdbcOperations.deleteStudents();
			   break; 
		case 4://update
			    System.out.println("update student");
			    JdbcOperations.updateStudents();
			     break;
		 default: System.out.println("Invalid input");
		}
		System.out.println("Do want to continue y/n");
		ch=sc.next().charAt(0);
		if(ch=='n' || ch=='N')
			break;
		}
		System.out.println("Your program is terminated");
	}
}
