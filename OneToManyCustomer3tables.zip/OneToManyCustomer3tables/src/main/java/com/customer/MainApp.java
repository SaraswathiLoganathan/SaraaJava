package com.customer;

import java.util.HashSet;
import java.util.Set;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;
public class MainApp 
{
 public static void main( String[] args )
 {
	 Configuration con= new Configuration().configure().addAnnotatedClass(Customer.class).addAnnotatedClass(Vendor.class);
	 ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
	 SessionFactory factory= con.buildSessionFactory(reg);
	 Session session= factory.openSession();
	 Transaction t= session.beginTransaction();
 Vendor vendor= new Vendor();
 vendor.setVendid(01);
 vendor.setName("Navvi");
 Customer customer= new Customer();
 customer.setCid(21);
 customer.setCname("Giri");
 Customer c= new Customer();
 c.setCid(42);
 c.setCname("Priya");
 Set s= new HashSet();
 s.add(customer);
 s.add(c);
 vendor.setChildren(s);
 
 session.persist(vendor);
 t.commit();
 session.close();
 System.out.println("saved successfully");

 }
} 