package com.customer;


	import java.util.Set;
	import javax.persistence.CascadeType;
	import javax.persistence.Column;
	import javax.persistence.Entity;
	import javax.persistence.FetchType;
	import javax.persistence.Id;
	import javax.persistence.OneToMany;
	import javax.persistence.Table;
	@Entity
	@Table(name="vendor")
	public class Vendor {
	 @Id
	 @Column(name="vid")
	 private int vendid;
	 @Column(name="vname")
	 private String name;
	 @OneToMany(fetch=FetchType.LAZY,targetEntity=Customer.class,cascade=CascadeType.ALL)
	 private Set children;
	 public int getVendid() {
	 return vendid;
	 }
	 public void setVendid(int vendid) {
	 this.vendid = vendid;
	 }
	 public String getName() {
	 return name;
	 }
	 public void setName(String name) {
	 this.name = name;
	 }
	 public Set getChildren() {
	 return children;
	 }
	 public void setChildren(Set children) {
	 this.children = children;
	 }
	 }



