package com.prepared;

import java.sql.SQLException;
import java.util.Scanner;

import com.prepared.MainPreparedOperation;

public class MainPreparedOperation {

	public static void main(String[] args) throws SQLException {
		Scanner sc=new Scanner(System.in);
		int choice;
		char ch;
		while(true) {
		System.out.println("*********MENU***************");
		System.out.println("Database operations");
		System.out.println("Enter your choice");
		System.out.println("1.Display product");
		System.out.println("2.Add product");
		System.out.println("3.Delete product based on product id");
		System.out.println("4.update product");
		
		choice=sc.nextInt();
		switch(choice) {
		case 1: //display
			    System.out.println("display all product");
			    PreparedOperations.displayEmployee();
			    break;
			  		case 2: //add students
			  			     System.out.println("Add new product");
			  			    PreparedOperations.displayEmployee();
			  			    break;
			  		case 3: //delete based on id
			  			      System.out.println("delete product based on id");
			  			      PreparedOperations.deleteEmployee();
			  			   break; 
			  		case 4://update
			  			    System.out.println("update product");
			  			    PreparedOperations.updateEmployee();
			  			     break;
			  		 default: System.out.println("Invalid input");
			  		}
			  		System.out.println("Do want to continue y/n");
			  		ch=sc.next().charAt(0);
			  		if(ch=='n' || ch=='N')
			  			break;
			  		}
			  		System.out.println("Your program is terminated");
			  	}
			  }
