package com.prepared;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.prepared.DatabaseConnections;

public class PreparedOperations {
	
	private static Connection myconn; 
	private static Statement st;
	private static ResultSet rs;
	
	
	public static void displayEmployee() throws SQLException {
		myconn=DatabaseConnections.getConnection();
		st=myconn.createStatement();
		String sel="select * from employee";
		rs=st.executeQuery(sel);
		
		System.out.println("eid\tename\teage\tesalary\temail");
		  
		  while(rs.next()) {
			  int sn=rs.getInt(1);
			  String sname=rs.getString(2);
			  int cid=rs.getInt(3);
			  float fs=rs.getFloat(4);
			  String sd=rs.getString(5);
			  System.out.println(sn+"\t"+sname+"\t"+cid+"\t"+fs+"\t"+sd);
		  }
	}
	
	public static void addEmployee() throws SQLException {
		myconn=DatabaseConnections.getConnection();
		st=myconn.createStatement();
		PreparedStatement pst=null;
	
		int sid,cid;
		String name,sd;
		float salary;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the ename");
		String n=sc.next();
		System.out.println("Enter eid");
		sid=sc.nextInt();
		System.out.println("Enter the eage");
		cid=sc.nextInt();
		System.out.println("Enter the esalary");
		salary=sc.nextFloat();
		System.out.println("Enter the email");
		sd=sc.next();
		//check sid exists
		String sel="select * from employee where eid=?";
		pst=myconn.prepareStatement(sel);
		
		pst.setInt(1, sid);
		rs=pst.executeQuery();
		//System.out.println(rs);
		if(!rs.next()) {
			String ins="insert into employee values(?,?,?,?,?)";
			pst=myconn.prepareStatement(ins);
			pst.setInt(1, sid);
			pst.setString(2, n);
			pst.setInt(3, cid);
			pst.setString(4, sd);
			pst.setFloat(5, salary);
			int rv=pst.executeUpdate();
			System.out.println(rv);
			if(rv>0) {
				System.out.println("Record is inserted");
			}
			else {
				System.out.println("Not inserted");
			}
		}else {
			System.out.println(sid+" already exists");
		}
		
	}

public static void deleteEmployee() throws SQLException {
	myconn=DatabaseConnections.getConnection();
	st=myconn.createStatement();
	PreparedStatement pst=null;
	int stdid;

	Scanner sc=new Scanner(System.in);
	System.out.println("Enter employee id to delete record");
	stdid=sc.nextInt();
	
	String sel="select * from employee where eid=?";
	pst=myconn.prepareStatement(sel);
	pst.setInt(1, stdid);
	rs=pst.executeQuery();
	if(rs.next()) {
	
	String del="delete from employee where eid=?";
	pst=myconn.prepareStatement(del);
	pst.setInt(1, stdid);
	int rv=pst.executeUpdate();
	
	if(rv>0) {
		System.out.println("Record is deleted");
	}else {
		System.out.println("ERROR!!!!!");
	}
	}else {
		System.out.println("Student id "+stdid+" not exists");
	}
}

public static void updateEmployee() throws SQLException {
	int stdid;
	Connection conn=null;
	ResultSet rs=null;
	PreparedStatement pst=null;
	
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter student id to update record");
	stdid=sc.nextInt();
	System.out.println("Enter name to change");
	String sn=sc.next();
	
	//check for student existence
	String sel="select * from students where sid=?";
	pst=conn.prepareStatement(sel);
	
	pst.setInt(1, stdid);
	rs=pst.executeQuery();
	if(rs.next()) {
		//if record exists then go for update
		String upd="update students set sname=? where sid=?";
		pst=conn.prepareStatement(upd);
		pst.setString(1, sn);
		pst.setInt(2, stdid);
		
		int rv=pst.executeUpdate();
		if(rv>0) {
			System.out.println("name is changed successfully");
		}else {
			System.out.println("ERRROR||||||");
		}
		
	}else {
		System.out.println(stdid+" not exists");
	}
}
}