package prodOper;

import java.sql.SQLException;
import java.util.Scanner;
  
public class MainProdOperations {

	public static void main(String[] args) throws SQLException {
		
			Scanner sc=new Scanner(System.in);
			
			int choice;
			
			char ch;
			
			while(true) {
				
			System.out.println("*********MENU***************");
			
			System.out.println("Database operations");
			
			System.out.println("Enter your choice");
			
			System.out.println("1.Display products");
			
			System.out.println("2.Add products");
			
			System.out.println("3.Delete products based on products id");
			
			System.out.println("4.update products");
			
			choice=sc.nextInt();
			
			switch(choice) {
			
			case 1: //display
				
				    System.out.println("display all products");
				    
				    ProdOperations.displayProduct();
				    
				    break;
			case 2: //add students
				
				     System.out.println("Add new products");
				    
				     ProdOperations.addProduct();
				     
				    break;
				    
			case 3: //delete based on id
				
				      System.out.println("delete products based on id");
				     
				      ProdOperations.deleteproduct();
				    
				   break; 
				   
			case 4://update
				
				    System.out.println("update products");
				    
				    ProdOperations.updateproduct();
				  
			System.out.println("Do want to continue y/n");
			
			ch=sc.next().charAt(0);
			
			if(ch=='n' || ch=='N')
				
				break;
			}
			
			System.out.println("Your program is terminated");
		}
	

	}
}


