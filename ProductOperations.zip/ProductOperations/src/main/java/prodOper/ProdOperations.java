package prodOper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import prodOper.DatabaseConnProd;



public class ProdOperations {
	private static Connection myconn; 
	private static Statement st;
	private static ResultSet rs;
	
	
	public static void displayProduct() throws SQLException {
		myconn=DatabaseConnProd.getConnection();
		st=myconn.createStatement();
		String sel="select * from product";
		rs=st.executeQuery(sel);
		
		System.out.println("pid\tpname\tpprice\tp_exp");
		  
		  while(rs.next()) {
			  int id=rs.getInt(1);
			  String name=rs.getString(2);
			  float price=rs.getFloat(3);
			  String exp=rs.getString(4);
			  System.out.println(id+"\t"+name+"\t"+price+"\t"+exp);
		  }
	}
	
	public static void addProduct() throws SQLException {
		myconn=DatabaseConnProd.getConnection();
		st=myconn.createStatement();
		PreparedStatement pst=null;
	
		int id;
		String name,exp;
		float price;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter pid");
		id=sc.nextInt();
		System.out.println("Enter the pname");
		String n=sc.next();
		System.out.println("Enter the pprice");
		price=sc.nextFloat();
		System.out.println("Enter the p_exp");
		exp=sc.next();
		//check sid exists
		String sel="select * from product where pid=?";
		pst=myconn.prepareStatement(sel);
		
		pst.setInt(1, id);
		rs=pst.executeQuery();
		//System.out.println(rs);
		if(!rs.next()) {
			String ins="insert into product values(?,?,?,?)";
			pst=myconn.prepareStatement(ins);
			pst.setInt(1, id);
			pst.setString(2, n);
			pst.setString(3, exp);
			pst.setFloat(4, price);
			int rv=pst.executeUpdate();
			System.out.println(rv);
			if(rv>0) {
				System.out.println("Record is inserted");
			}
			else {
				System.out.println("Not inserted");
			}
		}else {
			System.out.println(id+" already exists");
		}
		
	}

public static void deleteproduct() throws SQLException {
	myconn=DatabaseConnProd.getConnection();
	st=myconn.createStatement();
	PreparedStatement pst=null;
	int stdid;

	Scanner sc=new Scanner(System.in);
	System.out.println("Enter product id to delete record");
	stdid=sc.nextInt();
	
	String sel="select * from product where pid=?";
	pst=myconn.prepareStatement(sel);
	pst.setInt(1, stdid);
	rs=pst.executeQuery();
	if(rs.next()) {
	
	String del="delete from product where pid=?";
	pst=myconn.prepareStatement(del);
	pst.setInt(1, stdid);
	int rv=pst.executeUpdate();
	
	if(rv>0) {
		System.out.println("Record is deleted");
	}else {
		System.out.println("ERROR!!!!!");
	}
	}else {
		System.out.println("product id "+stdid+" not exists");
	}
}

public static void updateproduct() throws SQLException {
	int stdid;
	Connection conn=null;
	ResultSet rs=null;
	PreparedStatement pst=null;
	
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter product id to update record");
	stdid=sc.nextInt();
	System.out.println("Enter name to change");
	String sn=sc.next();
	
	//check for student existence
	String sel="select * from product where pid=?";
	pst=conn.prepareStatement(sel);
	
	pst.setInt(1, stdid);
	rs=pst.executeQuery();
	if(rs.next()) {
		//if record exists then go for update
		String upd="update product set pname=? where pid=?";
		pst=conn.prepareStatement(upd);
		pst.setString(1, sn);
		pst.setInt(2, stdid);
		
		int rv=pst.executeUpdate();
		if(rv>0) {
			System.out.println("name is changed successfully");
		}else {
			System.out.println("ERRROR||||||");
		}
		
	}else {
		System.out.println(stdid+" not exists");
	}
}
}