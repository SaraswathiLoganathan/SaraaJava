package proj.com;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Opration {
	private static Connection con;
	private static Scanner sc=new Scanner(System.in);
	private static PreparedStatement pst;
	private static ResultSet rst;
	private static String email;
	private static String username;
	private static int t;
	private static int s;
	private static String password;
	private static int seatno;
	private static int ch;
	private static String tripname;
	private static String depaturetime;
	private static String arrivaltime;
	private static String seattype;
	private static long ticketamount;
	private static long inventoryfare;
	private static String tickettype;
	private static long totalamount;
	private static long accno;
	private static int pinno;
	
	public static void seatReservation (){
	{
	try
	{
	int totalNoOfSeats=50;
	int avalseatcount=50;
	con=DbConn.getConnection();
	String  com="select seatno from seat_reservation order by seatno";
	pst=con.prepareStatement(com);
	rst=pst.executeQuery();

	while(rst.next())
	{
	System.out.print(rst.getInt(1)+" ");
	}

	System.out.println("Already These Seats are RESERVED");
	String  count="select count(*) from seat_reservation";
	pst=con.prepareStatement(count);
	rst=pst.executeQuery();
	while(rst.next())
	{
	int reservedseat=rst.getInt(1);
	//SELECTING SEAT NUMBER
	while(true) {
	System.out.println("Total number of seats"+totalNoOfSeats);
	System.out.println("available seat count"+(avalseatcount-reservedseat));
	System.out.println("Enter The Seat No");
	seatno=sc.nextInt();
	String sql1="select * from seat_reservation where seatno=?";
	pst=con.prepareStatement(sql1);
	pst.setInt(1, seatno);
	rst=pst.executeQuery();
	//entering personal details
	if(!rst.next())
	{   System.out.println("Enter Passanger Name");
	String name=sc.next();
	System.out.println("Enter Your MobileNo");
	String mobno=sc.next();
	System.out.println("Enter Your full Address");
	System.out.println("Door No");
	String doorno=sc.next();
	sc.nextLine();
	System.out.println("Enter the Street Name");
	String streetname=sc.nextLine();
	System.out.println("Enter Your Location");
	String location=sc.nextLine();
	System.out.println("Enter the Pincode");
	int pincode=sc.nextInt();
	while(true)
	{
	System.out.println("Which Trip you want to Choose");
	System.out.println("1.CHENNAI TO BANGALORE");
	System.out.println("2.CHENNAI TO HYDRABED");
	System.out.println("3.CHENNAI TO PUNE");
	ch=sc.nextInt();
	if(ch<4)
	{
	switch(ch)
	{
	case 1:System.out.println("Your selected Chennai to Bangalore option");
	tripname="CHENNAI TO BANGALORE";
	break;
	case 2:System.out.println("your selected Chennai to hydrabed option");
	tripname="CHENNAI TO HYDRABED";
	break;
	case 3:System.out.println("your selected Chennai to Pune option");
	tripname="CHENNAI TO PUNE";
	break;

	}break;
	}
	else
	{
	System.out.println("INVALID OPTION");
	}
	}
	//SELECTING TIMING***********************************************************

	
	while(true) {
	System.out.println("Select which Time you Want..");

	System.out.println("1.DEPATURE TIME is 10.00AM and ARRIVAL TIME is 2.00PM");
	System.out.println("2.DEPATURE TIME is 11.00AM and ARRIVAL TIME is 3.10PM");
	System.out.println("3.DEPATURE TIME is 11.30AM and ARRIVAL TIME is 4.45PM");
	t=sc.nextInt();
	if(t<4)
	{
	switch(t)
	{
	case 1:System.out.println("your Depature time is 10.00AM ");
	depaturetime="10:00:00 AM";
	System.out.println("your Depature time is 10.00AM");
	arrivaltime="02:00:00 PM";

	break;
	case 2:System.out.println("your DEPATURE TIME is 11.00AM and ARRIVAL TIME is 3.10PM");
	depaturetime="11:00:00 AM";
	arrivaltime="03:10:00 PM";
	break;
	case 3:System.out.println("your DEPATURE TIME is 11.30AM and ARRIVAL TIME is 4.45PM ");
	depaturetime="11:30:00 AM";
	arrivaltime="04:45:00 PM";
	break;

	}break;
	}
	else
	{
	System.out.println("invalid option...");

	}}
	
	while(true) {
	System.out.println("select which type of seat you want");
	System.out.println("1.AISLE SEAT");
	System.out.println("2.WINDOW SEAT");
	s=sc.nextInt();
	if(s<3)
	{
	switch(s){
	case 1:System.out.println("your selected the type is AISLE SEAT (A and F rows)");
	seattype="aisel type";
	break;

	case 2:System.out.println("your selected the type is WINDOW SEAT(C and D rows)");
	seattype="window type";
	break;
	}
	break;
	}
	else
	{
	System.out.println("invalid option...");}}
	//SELECTING TICKET TYPE
	
	while(true)
	{

	System.out.println("1.FIRST CLASS ticket price is 9000");
	System.out.println("2.NORMAL CLASS ticket price is 4000");
	System.out.println("enter your choice");
	int ch=sc.nextInt();
	if(ch<3)
	{
	switch(ch)
	{
	case 1:System.out.println("your selected FIRST CLASS ticket");
	tickettype="first class";
	ticketamount=6000;
	break;
	case 2:System.out.println("your selected NORMAL CLASS ticket");
	tickettype="normal class";
	ticketamount=4000;
	break;
	}break;
	}}
	//SELECTING LUGGAGE WEIGHT
	
	while(true)
	{

	System.out.println("1.Inventory spare is 8kg then fare is 1000");
	System.out.println("2.Inventory spare is 3kg then fare is 500");
	System.out.println("enter your choice");
	int fare=sc.nextInt();
	if(fare<3)
	{
	switch(fare)
	{
	case 1:System.out.println("your selected 8kg");

	inventoryfare=1000;
	break;
	case 2:System.out.println("your selected 3kg");
	inventoryfare =500;
	break;
	}
	break;}
	}
	
	while(true)
	{
	totalamount=ticketamount+inventoryfare;
	System.out.println("GO TO PAYMENT");
	System.out.println("Enter your Account Number");
	accno=sc.nextLong();
	System.out.println("Enter your Pin Number");
	pinno=sc.nextInt();
	String transacc="select accno from cus_acc where accno=?";
	pst=con.prepareStatement(transacc);
	pst.setLong(1, accno);
	rst=pst.executeQuery();
	if(rst.next())
	{
	String transpin="select pinno from cus_acc where pinno=?";
	pst=con.prepareStatement(transpin);
	pst.setLong(1, pinno);
	rst=pst.executeQuery();
	if(rst.next())
	{

	String ins="insert into seat_reservation values(?,?,?,?,?,?,?)";
	pst=con.prepareStatement(ins);
	pst.setInt(1, seatno);
	pst.setString(2, name);
	pst.setString(3, mobno);
	pst.setString(4, doorno);
	pst.setString(5, streetname);
	pst.setString(6, location);
	pst.setInt(7, pincode);
	int i=pst.executeUpdate();
	if(i>0)
	{
	String seatch="insert into flight_timing_details values(?,?,?,?,?,?,?,?)";
	pst=con.prepareStatement(seatch);
	pst.setInt(1, ch);
	pst.setString(2, tripname);
	pst.setInt(3, t);
	pst.setString(4, depaturetime);
	pst.setString(5, arrivaltime);
	pst.setInt(6, s);
	pst.setString(7, seattype);
	pst.setInt(8, seatno);
	int p=pst.executeUpdate();
	if(p>0)
	{
	String fare="insert into ticket_fare_details values(?,?,?,?,?)";
	pst=con.prepareStatement(fare);
	pst.setString(1, tickettype);
	pst.setLong(2, ticketamount);
	pst.setLong(3, inventoryfare);
	pst.setLong(4, totalamount);
	pst.setInt(5, seatno);
	int k=pst.executeUpdate();
	if(k>0)
	{
	String bal="select balance from cus_acc where (select balance from cus_acc where accno=?)>0";
	pst=con.prepareStatement(bal);
	pst.setLong(1,accno);

	rst=pst.executeQuery();
	if(rst.next())
	{

	String withdraw="update cus_acc set balance=balance-(select totalfare from ticket_fare_details where seatno=?) where accno=? ";
	pst=con.prepareStatement(withdraw);
	pst.setLong(1,seatno);
	pst.setLong(2,accno);
	int t=pst.executeUpdate();
	if(t>0)
	{

	String deposite="insert into admin_acc values(?,?)";
	pst=con.prepareStatement(deposite);
	pst.setLong(1, totalamount);
	pst.setInt(2, seatno);
	int l=pst.executeUpdate();
	//**************************************
	if(l>0)
	{
	System.out.println("your seat is reserved");
	System.out.println("Do you want to See the Whole details about your reservation yes/no");
	String m=sc.next();
	if(m.equalsIgnoreCase("yes"))
	{

	Opration.displayReservationDetails();
	totalNoOfSeats=totalNoOfSeats-1;
	break;
	}
	else
	{
	break;
	}
	}
	break;
	}}
	else
	{
	System.out.println("Insufficient balance");
	String delfare="delete from ticket_fare_details where seatno=?";
	pst=con.prepareStatement(delfare);
	pst.setInt(1, seatno);
	int df=pst.executeUpdate();
	if(df>0)
	{
	String deltime="delete from flight_timing_details where seatno=?";
	pst=con.prepareStatement(deltime);
	pst.setInt(1, seatno);
	int dt=pst.executeUpdate();
	if(dt>0)
	{
	String delseat="delete from seat_reservation where seatno=?";
	pst=con.prepareStatement(delseat);
	pst.setInt(1, seatno);
	int ds=pst.executeUpdate();
	if(ds>0)
	{
	System.out.println("check your balance");
	break;
	}
	}
	}
	}}}}}
	}else
	{
	System.out.println("invalid account number or pin number");

	}
	}
	}else
	{
	System.out.println("This seat no is already reserved... ");

	}
	avalseatcount=totalNoOfSeats-1;
	break;
	}

	}
	}catch (Exception e) {
	e.printStackTrace();}}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public static void displayReservationDetails()
	{
	try
	{
	con=DbConn.getConnection();

	String de="select * from seat_reservation  where seatno=?";
	pst=con.prepareStatement(de);
	pst.setInt(1,seatno);
	rst=pst.executeQuery();
	while(rst.next())
	{
	System.out.println("----------------------------------------------PERSONAL DETAILS-----------------------------------------");
	System.out.println("_________________________________________________________________________________________________________________________");
	System.out.println("Seatno\t\tName\t\t\tMobno\t\tDoorno\t\tStreetname\t\t\tLocation\tPincode");
	System.out.println("_________________________________________________________________________________________________________________________ ");
	System.out.println(rst.getInt(1)+"\t\t"+rst.getString(2)+"\t\t"+rst.getString(3)+"\t\t"+rst.getString(4)+"\t\t"+rst.getString(5)+"\t"+rst.getString(6)+"\t\t"+rst.getInt(7)+"\t");
	System.out.println("__________________________________________________________________________________________________________________________ ");
	String seatch="select * from flight_timing_detail where seatno=?";
	pst=con.prepareStatement(seatch);
	pst.setInt(1, seatno);
	rst=pst.executeQuery();
	while(rst.next())
	{ System.out.println(        );
	System.out.println("--------------------------TRAVELLING DETAILS-------------------------");
	System.out.println("______________________________________________________________________________________");
	System.out.println("Traveling place\t\tsdeparture time\t\tarrival time\t\tSeattype\t");
	System.out.println("____________________________________________________________________________________");
	System.out.println(rst.getString(2)+"\t\t"+rst.getString(4)+"\t\t"+rst.getString(5)+"\t\t"+rst.getString(7)+"\t");
	System.out.println("____________________________________________________________________________________");
	String farech="select * from ticket_fare_detail where seatno=?";
	pst=con.prepareStatement(farech);
	pst.setInt(1, seatno);
	rst=pst.executeQuery();
	while(rst.next())
	{
	System.out.println(        );
	System.out.println("-----------------------FARE DETAILS--------------------------------");
	System.out.println("_______________________________________________________________");
	System.out.println("Tickettype\tticketamount\tinventoryfare\ttotalamount");
	System.out.println("_______________________________________________________________");

	System.out.println(rst.getString(1)+"\t"+rst.getInt(2)+"\t\t"+rst.getInt(3)+"\t\t"+rst.getInt(4)+"\t");
	System.out.println("_______________________________________________________________");
	break;
	}
	}break;
	}
	}
	catch(Exception e)
	{
	e.printStackTrace();
	}
	}

}
