package digit.count;

import java.util.Scanner;

public class CountDigitNumber {

	public static void main(String[] args) {
		int n , digit=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		n=sc.nextInt();
		
			while(n!=0) {
	            n = n / 10;
	            digit++;
	        }       
	        System.out.print(digit);
	 
		}

	}


