package overriding.com;

public class Abstract {
	public static void main(String[] args) {
		Addition a = new Addition();
		a.display();

	}

}
abstract class Cal {
	abstract void display();
	
}
class Addition extends Cal{
	 void display() {
		 System.out.println("Add");
	}
}
class Sub extends Cal{
	void display() {
		System.out.println("Sub");
	}
}