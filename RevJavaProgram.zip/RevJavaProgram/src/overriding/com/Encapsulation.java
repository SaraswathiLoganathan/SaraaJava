package overriding.com;

class Area{
	private int length;
	private int breadth;
	private int areaofrectangle;
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	public int getBreadth() {
		return breadth;
	}
	public void setBreadth(int breadth) {
		this.breadth = breadth;
	}
	public void Calarea() {
		 areaofrectangle=length*breadth;
		System.out.println("Area of rectangle is = "+areaofrectangle);
	}
	
}
public class Encapsulation {

	public static void main(String[] args) {
		Area aob=new Area();
		aob.setLength(11);
		aob.setBreadth(15);
		aob.Calarea();

	}

}
