package overriding.com;

class ParentClass{
	public void add() {
		System.out.println("parent class called");
	}
}
class Child extends ParentClass{
	@Override
	public void add() {
		System.out.println("child class called");
		super.add();
	}
	
}
public class FunOverriding {

	public static void main(String[] args) {
Child cob=new Child();

cob.add();
System.out.println("main");


}

}
