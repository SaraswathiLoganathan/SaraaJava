package overriding.com;

public class Interface {

}
