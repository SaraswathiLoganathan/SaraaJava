package overriding.com;

class Calculation{
	public void sum(int a, int b) {
		System.out.println("Addition is="+(a+b));
	}
	public void sum(float a, float b) {
		System.out.println("Addition is="+(a+b));
	}
}

public class Overloding {

	public static void main(String[] args) {
		Calculation cob=new Calculation();
		//cob.sum(2, 3);
		cob.sum(2.5f, 3.6f);

	}

}
