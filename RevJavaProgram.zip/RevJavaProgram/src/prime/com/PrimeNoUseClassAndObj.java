package prime.com;

import java.util.Scanner;

public class PrimeNoUseClassAndObj {
	
}