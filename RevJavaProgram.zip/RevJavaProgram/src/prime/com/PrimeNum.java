package prime.com;

import java.util.Scanner;

public class PrimeNum {
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number");
		int no=sc.nextInt();
		
		int a=0;
		for(int i=1;i<=no;i++) {
			if(no%i==0) {
				a=a+1;
			}
		}
		if(a==2) {
			System.out.println(no+" is prime");
		}else {
			System.out.println(no+ " is not a prime");
		}
	}

	}


