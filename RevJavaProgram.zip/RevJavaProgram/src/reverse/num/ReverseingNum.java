package reverse.num;

import java.util.Scanner;

public class ReverseingNum {

	public static void main(String[] args) {
		int n;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		n=sc.nextInt();
		int rev=0;
			while(n>0) {
	            int remainder = n % 10;
	            rev = rev * 10 + remainder;
	            n = n / 10;
	        }       
	        System.out.print("The reverse of the given number is = "+rev);
	 
		}

	}


