package sql.com;

public class DelectRecordMain {

	public static void main(String[] args) {
		

	}

}
