package sql.com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class InsertRecordDatabaseMain {

	public static void main(String[] args) {
		String driver="com.mysql.cj.jdbc.Driver"; //Driver class
		String url="jdbc:mysql://localhost:3306/saraasqldatabase";
		String un="root";
		String up="root";
		Connection conn=null;
		Statement st=null;
		ResultSet rs=null;
		int sid,cid;
		String sn,sd;
		float fs;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter student name");
		sn=sc.next();
		System.out.println("Enter Student id");
		sid=sc.nextInt();
		System.out.println("Enter student fees");
		fs=sc.nextFloat();
		System.out.println("Enter cid");
		cid=sc.nextInt();
		System.out.println("Enter DOB");
		sd=sc.next();
		
		
		try {
			Class.forName(driver); //load the driver at run time, register 
			conn = DriverManager.getConnection(url,un,up); //create the connection
			st=conn.createStatement(); //Creating statement
			//System.out.println(conn);
			//check record exists
			String sel="select * from students where sid="+sid;
			rs=st.executeQuery(sel);
			if(rs.next()){
				System.out.println(sid+" already exists");
			}else {
			
			
			String ins="insert into students values("+sid+",'"+sn+"',"+cid+","+fs+",'"+sd+"')";
			System.out.println(ins);
			int rval=st.executeUpdate(ins);//for insert , update and delete use exceuteUpdate
			if(rval>0) {
				System.out.println("Record is added");
			}
			else {
				System.out.println("Error Occurred");
				
			}
			}
			
	}catch(Exception e) {
		e.printStackTrace();
	}
	}
}
