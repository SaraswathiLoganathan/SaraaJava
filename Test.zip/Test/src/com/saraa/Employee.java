package com.saraa;

public class Employee {

	 int eid;
	 String ename;
	float esalary;
	
	//right click->go to source->generate constructor using fields

	public Employee(int eid, String ename, float esalary) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.esalary = esalary;
	
	}

	//right click->go to source->generate to strings

	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", esalary=" + esalary + "]";
	}

}
