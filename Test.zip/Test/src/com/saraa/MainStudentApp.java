package com.saraa;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;

public class MainStudentApp {

	public static void main(String[] args) {
		Student s1=new Student(1, "Mani", 25, 40000.040);
		Student s2=new Student(2, "Rani", 24, 30000.090);
		Student s3=new Student(3, "Saran",23, 50000.80);
		Student s4=new Student(4, "Navi",21, 20000.89);
		Student s5=new Student(5, "Meena",33, 50000.90);
		Student s6=new Student(6, "Dharani",26, 70000.50);
		Student s7=new Student(7, "Saraa",27, 70000.07);

		
		LinkedList<Student> std=new LinkedList<Student>();
		std.add(s1);
		std.add(s2);
		std.add(s3);
		std.add(s4);
		std.add(s5);
		std.add(s6);
		std.add(s7);
		System.out.println(std);
		
		//Sort by age
		StudentSageSort sage=new StudentSageSort();
		Collections.sort(std,sage);
		System.out.println("Student sorted by age");
		Iterator<Student> sortsage=std.iterator();
		System.out.println("Sid\\tsname\\tsage\\tsfees");
		while(sortsage.hasNext()) {
			Student e=sortsage.next();
			System.out.println(e.sid+"\t"+e.sname+"\t"+e.age+"\t"+e.sfees);			

		//Sort by fees
			
			StudentSortFees sfees=new StudentSortFees();
			Collections.sort(std,sfees);
			
			System.out.println("Student Sorted by fees");
			Iterator<Student> sortsfees=std.iterator();
			System.out.println("SID\\tSNAME\\tSAGE\\tSFEES");
			
			while(sortsfees.hasNext());
				Student e1=sortsfees.next();
				System.out.println(e1.sid+"\t"+e1.sname+"\t"+e1.age+"\t"+e1.sfees);
		}
	}
}
