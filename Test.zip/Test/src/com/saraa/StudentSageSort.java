package com.saraa;

import java.util.Comparator;


	class StudentSageSort implements Comparator<Student>{

		@Override
		public int compare(Student o1, Student o2) {
			if(o1.age>o2.age) {
			return 1;
		}else if(o1.age==o2.age) {
			return 0;
			
		}else {
			return -1;
		}
	}
}

