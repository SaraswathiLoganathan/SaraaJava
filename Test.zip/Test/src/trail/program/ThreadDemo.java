package trail.program;
 
public class ThreadDemo extends Thread {
      // initiated run method for Thread
	 public static int amount = 0;

    
    public static void main(String[] args)
    {
    	 Thread thread = new Thread();
    	    thread.start();
    	    System.out.println(amount);
    	    amount++;
    	    System.out.println(amount);
    	  }

    	  public void run() {
    	    amount++;
}
}