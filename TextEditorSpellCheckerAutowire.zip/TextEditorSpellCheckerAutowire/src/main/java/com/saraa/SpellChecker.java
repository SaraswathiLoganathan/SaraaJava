package com.saraa;

public class SpellChecker {
public void checkFun() {
		
		System.out.println("spellcheck is Working");
}
}