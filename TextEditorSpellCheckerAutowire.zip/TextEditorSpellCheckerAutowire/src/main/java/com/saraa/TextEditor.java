package com.saraa;

import org.springframework.beans.factory.annotation.Autowired;

public class TextEditor {
	@Autowired
	SpellChecker spellchecker;
	public void  text() {
		System.out.println("TextEditor method");
		if(spellchecker!=null) {
			spellchecker.checkFun();
		}else {
			System.out.println("SpellChecker is not working");
		}
	}
	

}

