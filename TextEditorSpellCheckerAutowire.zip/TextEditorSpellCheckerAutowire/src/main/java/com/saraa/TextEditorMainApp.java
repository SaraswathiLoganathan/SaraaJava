package com.saraa;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TextEditorMainApp {

	public static void main(String[] args) {
		
		ApplicationContext ctx=new ClassPathXmlApplicationContext("springs.xml");
		TextEditor ob=(TextEditor) ctx.getBean("TextEditor");
		ob.text();
		
		
	}

}
