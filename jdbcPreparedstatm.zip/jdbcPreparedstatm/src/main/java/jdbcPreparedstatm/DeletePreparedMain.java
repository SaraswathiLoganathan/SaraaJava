package jdbcPreparedstatm;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.util.Scanner;


public class DeletePreparedMain {

	public static void main(String[] args) {
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/saraasqldatabase";
		String un="root";
		String up="root";
		int stdid;
		Connection conn=null;
		ResultSet rs=null;
		PreparedStatement pst=null;
		
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter student id to delete record");
		stdid=sc.nextInt();
		try {
			Class.forName(driver);
			conn=DriverManager.getConnection(url,un,up);
			
			String sel="select * from students where sid=?";
			pst=conn.prepareStatement(sel);
			pst.setInt(1, stdid);
			rs=pst.executeQuery();
			if(rs.next()) {
			
			String del="delete from students where sid=?";
			pst=conn.prepareStatement(del);
			pst.setInt(1, stdid);
			int rv=pst.executeUpdate();
			
			if(rv>0) {
				System.out.println("Record is deleted");
			}else {
				System.out.println("ERROR!!!!!");
			}
			}else {
				System.out.println("Student id "+stdid+" not exists");
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
