package jdbcPreparedstatm;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class InsertStatePrepred {
	public static void main(String[] args) throws SQLException {
		String driver ="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/saraasqldatabase";
		String un="root";
		String up="root";
		
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		
		int sid,cid;
		String name,sd;
		float fees;
		
		try {
			Class.forName(driver); //load the driver at run time, register 
			conn = DriverManager.getConnection(url,un,up);
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the name");
		String n=sc.next();
		System.out.println("Enter id");
		sid=sc.nextInt();
		System.out.println("Enter the cid");
		cid=sc.nextInt();
		System.out.println("Enter the DOB");
		sd=sc.next();
		System.out.println("Enter the fees");
		fees=sc.nextFloat();
		//check sid exists
		String sel="select * from students where sid=?";
		pst=conn.prepareStatement(sel);
		
		pst.setInt(1, sid);
		rs=pst.executeQuery();
		//System.out.println(rs);
		if(!rs.next()) {
			String ins="insert into students values(?,?,?,?,?)";
			pst=conn.prepareStatement(ins);
			pst.setInt(1, sid);
			pst.setString(2, n);
			pst.setInt(3, cid);
			pst.setString(4, sd);
			pst.setFloat(5, fees);
			int rv=pst.executeUpdate();
			System.out.println(rv);
			if(rv>0) {
				System.out.println("Record is inserted");
			}
			else {
				System.out.println("Not inserted");
			}
		}else {
			System.out.println(sid+" already exists");
		}
		}
	  
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}

