package jdbcPreparedstatm;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class RetrieveRecordPrepared {

	public static void main(String[] args) {
		String driver="com.mysql.cj.jdbc.Driver"; //Driver class
		String url="jdbc:mysql://localhost:3306/saraasqldatabase";
		String un="root";
		String up="root";
		
		Connection conn=null;
		PreparedStatement pst;
		ResultSet rs=null;
		
		try {
			Class.forName(driver);
			conn=DriverManager.getConnection(url,un,up);
			String selsql="select * from students";
			pst=conn.prepareStatement(selsql);
			rs=pst.executeQuery();
			System.out.println("sid\tsname\tcid\tsdate\t\tfees");
			
			while(rs.next()) {
				int id=rs.getInt("sid");
				String sn=rs.getString("sname");
				int cd=rs.getInt("cid");
				String sd=rs.getString("sdate");
				float fees=rs.getFloat("fees");
				System.out.println(id+"\t"+sn+"\t"+cd+"\t"+sd+"\t"+fees);
				
						
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
