package jdbcPreparedstatm;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class UpdateRecordPreparedstmt {

	public static void main(String[] args) throws SQLException {
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/saraasqldatabase";
		String un="root";
		String up="root";
		int stdid;
		Connection conn=null;
		ResultSet rs=null;
		PreparedStatement pst=null;
				try {
					Class.forName(driver);
					conn=DriverManager.getConnection(url,un,up);
				}catch(Exception e) {
					e.printStackTrace();
				}
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter student id to update record");
		stdid=sc.nextInt();
		System.out.println("Enter name to change");
		String sn=sc.next();
		
		//check for student existence
		String sel="select * from students where sid=?";
		pst=conn.prepareStatement(sel);
		
		pst.setInt(1, stdid);
		rs=pst.executeQuery();
		if(rs.next()) {
			//if record exists then go for update
			String upd="update students set sname=? where sid=?";
			pst=conn.prepareStatement(upd);
			pst.setString(1, sn);
			pst.setInt(2, stdid);
			
			int rv=pst.executeUpdate();
			if(rv>0) {
				System.out.println("name is changed successfully");
			}else {
				System.out.println("ERRROR||||||");
			}
			
		}else {
			System.out.println(stdid+" not exists");
		}
		

	}

}
