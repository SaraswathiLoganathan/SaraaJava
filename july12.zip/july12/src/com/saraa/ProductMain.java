package com.saraa;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class ProductMain {

	public static void main(String[] args) {
		Products p1=new Products(21, "Laptop", 30000);
		Products p2=new Products(11, "Disk", 40000);
		Products p3=new Products(15, "TV", 10000);
		
		ArrayList<Products> lst=new ArrayList<Products>();
		lst.add(p1);
		lst.add(p2);
		lst.add(p3);
		
		SortProductByPrice pr=new SortProductByPrice();
		
		Collections.sort(lst,pr);
		
		System.out.println("Sorting Based on price");
		Iterator<Products> pit=lst.iterator();
		System.out.println("PID\tPNAME\tPPRICE");
		while(pit.hasNext()) {
			Products pt=pit.next();
			System.out.println(pt.pid+"\t"+pt.pname+"\t"+pt.pprice);
		}
		
				SortPidProduct pid=new SortPidProduct();
				
				Collections.sort(lst,pid);
				
				System.out.println("Sorting Based on Product id");
				Iterator<Products> sortpid=lst.iterator();
				System.out.println("PID\tPNAME\tPPRICE");
				while(sortpid.hasNext()) {
					Products pt=sortpid.next();
					System.out.println(pt.pid+"\t"+pt.pname+"\t"+pt.pprice);
				}
				SortByNameProducts pname=new SortByNameProducts();
				Collections.sort(lst,pname);
				
				System.out.println("Product sorted by name");
				Iterator<Products> sortpname=lst.iterator();
				System.out.println("PId\tPNAME\tPPRICE");
				while(sortpname.hasNext()) {
					Products pt=sortpname.next();
					System.out.println(pt.pid+"\t"+pt.pname+"\t"+pt.pprice);
				}
				 
						
	}
	
	
	

}
