package com.saraa;

public class Products {
	int pid;
	String pname;
	float pprice;

	public Products(int pid, String pname, float pprice) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.pprice = pprice;
	}
	
	@Override
	public String toString() {
		return "Products [pid=" + pid + ", pname=" + pname + ", pprice=" + pprice + "]";
	}

}
