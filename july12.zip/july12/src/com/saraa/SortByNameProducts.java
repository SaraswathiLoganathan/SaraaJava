package com.saraa;

import java.util.Comparator;

public class SortByNameProducts implements Comparator<Products>{

	@Override
	public int compare(Products o1, Products o2) {
		return o1.pname.compareTo(o2.pname);
	}

}
