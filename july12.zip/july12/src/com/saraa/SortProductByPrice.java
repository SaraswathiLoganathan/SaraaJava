package com.saraa;

import java.util.Comparator;

public class SortProductByPrice implements Comparator<Products>{

	@Override
	public int compare(Products o1, Products o2) {
		if(o1.pprice==o2.pprice)
		return 0;
		 else if(o1.pprice>o2.pprice)
		return 1;
		else 
			return -1;
	}

	
}
