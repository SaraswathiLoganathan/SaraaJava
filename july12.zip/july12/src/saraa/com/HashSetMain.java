package saraa.com;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetMain {

	public static void main(String[] args) {
		HashSet<String> Student=new HashSet<String>();
			Student.add("Saraa");
			Student.add("Navi");
			Student.add("Dharani");
			Student.add("Kalai");
			Student.add("Meena");

			System.out.println("HashSet: "+Student);

				Iterator<String>it=Student.iterator();
				while(it.hasNext()) {
					System.out.println(it.next());
		}

	}

}
