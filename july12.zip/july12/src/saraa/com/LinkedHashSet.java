package saraa.com;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedHashSet {

	public static void main(String[] args) {
		
	LinkedList<String>ob=new LinkedList<String>();
	ob.add("java");
	ob.add("C++");
	ob.add("C");
	System.out.println("LinkedList:"+ob);
	
	Iterator<String> itr=ob.iterator();  
	  while(itr.hasNext()){  
	   System.out.println("Iterator:"+itr.next());  
	  }  
	  
	  ob.add(1, "SE");
	  System.out.println("Update LinkedList: "+ob);
	  
	  ob.set(2, "python");
	  System.out.println("change "+ob);
	  
	  String str=ob.get(3);
	  System.out.println("Access LinkedList: "+str);
	  
	  String ste=ob.remove(2);
	  System.out.println("Remove :"+ste);
	  
	}

}
