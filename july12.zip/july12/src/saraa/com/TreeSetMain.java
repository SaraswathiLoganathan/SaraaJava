package saraa.com;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetMain {

	public static void main(String[] args) {
		TreeSet<String> Employee=new TreeSet<String>();
		Employee.add("Mani");
		Employee.add("Saras");
		Employee.add("Navi");
		Employee.add("Deepa");
		Employee.add("Kiran");
		Employee.add("Ravi");

		System.out.println("TreeSet: "+Employee);

		Iterator<String>it=Employee.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}

	}

}
