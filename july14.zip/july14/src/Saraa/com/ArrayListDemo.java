package Saraa.com;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeSet;

public class ArrayListDemo {

	public static void main(String[] args) {
		ArrayList<String>st=new ArrayList<String>();
		st.add("Saras");
		st.add("Meena");
		st.add("Mani");
		st.add("Mani");
		st.add("balu");
	
		
		Iterator <String>itr=st.iterator();
		TreeSet<String>tst=new TreeSet<String>();
		while(itr.hasNext()) {
			tst.add(itr.next());
		}
		System.out.println(tst);
	}

}
