package Saraa.com;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

public class LinkedListDemo {
public static void main(String[]args){
	LinkedList<Integer>ob=new LinkedList<Integer>();
	int num,j=0;
	Scanner sc=new Scanner(System.in);
	System.out.println("how many number you want to enter:");
	num=sc.nextInt();
	System.out.println("Enter "+num+" Elements");
	for(int i=0;i<num;i++) {
		//j=sc.nextInt();
		//ob.add(j);
		ob.add(sc.nextInt());
	}
	Iterator<Integer>ob1=ob.iterator();
	while(ob1.hasNext()) {
		System.out.println(ob1.next());
	}
}
}