package Saraa.com;

import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;

public class TreeSetDemo {

	public static void main(String[] args) {
	TreeSet<String> tst=new TreeSet<String>();
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter how many number:");
	int num=sc.nextInt();
	for(int i=0;i<num;i++) {
		String value=sc.nextLine();
		tst.add(value);
	}
	Iterator<String>it=tst.iterator();
	while(it.hasNext()) {
		System.out.println(it.next());
	}

	}

}
