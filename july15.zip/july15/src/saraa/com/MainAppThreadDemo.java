package saraa.com;

class PrintTablea{
	 synchronized void displayMultTable(int n) { //lock
		for(int i=1;i<=10;i++) {
			System.out.println(n+"x"+i+"="+n*i);
		}
	}
}

class EduThread extends Thread{
	PrintTablea tob;
	public EduThread(PrintTablea t) {
		this.tob=t;
	}
	public void run() {
		tob.displayMultTable(2);
	}
}
class EduThreada extends Thread{
	PrintTablea tob1;
	public EduThreada(PrintTablea t) {
		this.tob1=t;
	}
	public void run() {
		tob1.displayMultTable(6);
	}
}

public class MainAppThreadDemo {

	public static void main(String[] args) throws InterruptedException {
		PrintTablea t=new PrintTablea();
		EduThread t1=new EduThread(t);
		EduThreada t2=new EduThreada(t);
		
		t1.start();
		
		t2.start();
		
		

	}

}
