package saraa.com;

class Thread1 extends Thread{
	public void run() {
		for(int i=1;i<=5;i++) {
			System.out.println(Thread.currentThread() +"i="+i);
		}
	}
}
public class ThreadMainApp {

	public static void main(String[] args) throws InterruptedException {
		Thread1 tob=new Thread1();  //new state
		Thread1 tob1=new Thread1();  
		tob.setName("first");
		System.out.println("tob is Alive "+tob.isAlive());
		tob.start();//runnable state
		              //whenever JVM starts execution of the object
		              //from runnable state it goes to run state
		System.out.println("tob is Alive "+tob.isAlive());
		System.out.println("tob1 is Alive "+tob.isAlive());
		tob.join();
		System.out.println("tob is Alive "+tob.isAlive());

		
		tob1.setName("second");
		tob1.start();
		System.out.println("tob1 is Alive "+tob1.isAlive());
		}
}
