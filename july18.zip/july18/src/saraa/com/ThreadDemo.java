package saraa.com;

class ExtendingThread extends Thread{
	public void run() {
		for( int i=1;i<=10;i++) {
			System.out.println("Extending thread");
			System.out.println(Thread.currentThread());
		}
	}
}
public class ThreadDemo {

	public static void main(String[] args) {
		ExtendingThread ob=new ExtendingThread();
		ExtendingThread ob1=new ExtendingThread();
		ob.setName("sa");
		ob1.setName("Sa1");
		ob.setPriority(1);//11 to 10
		ob1.setPriority(7);//highest
		
		ob.setPriority(Thread.MAX_PRIORITY);//10
		ob1.setPriority(Thread.MIN_PRIORITY);//1
		ob.setPriority(Thread.NORM_PRIORITY);//5
		ob.start();
		ob1.start();
		

	}

}
