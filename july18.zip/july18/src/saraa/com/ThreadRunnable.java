package saraa.com;

class Implment implements Runnable{

	@Override
	public void run() {
		System.out.println("good programing java");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
public class ThreadRunnable {

	public static void main(String[] args) {
		
		Implment obb=new Implment();
		
		Thread t1=new Thread(obb);
		t1.start();
		try {
			t1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
Implment obb1=new Implment();
		
		Thread t2=new Thread(obb1);
		t2.start();
		
	}

}
