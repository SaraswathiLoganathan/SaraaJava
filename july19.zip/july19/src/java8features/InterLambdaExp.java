package java8features;

@FunctionalInterface
interface CallInter{
	String myCallMethod(String s);
}
public class InterLambdaExp {

	public static void main(String[] args) {
		//using lambda expression
		CallInter mob=(s)->{
			return "Hello "+s;
			
		};
		String sob=mob.myCallMethod("Saraa");
			System.out.println(sob);
	}

}
