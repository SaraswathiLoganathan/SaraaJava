package java8features;
@FunctionalInterface
interface AddInt{
	int add(int i,int j);
}
@FunctionalInterface
interface subInt{
int sub(int i,int j);
}

@FunctionalInterface
interface MulInt{
	int prod(int i,int j);
}
@FunctionalInterface
interface divInt{
	int div(int i,int j);
}
public class LambdaCal {

	public static void main(String[] args) {
	/*AddInt aob=(i,j)->{
	  int s=i+j;
	  return s;
	  }
	 */
AddInt aob=(i,j)->i+j;
System.out.println("Add two no = "+aob.add(3,2));
subInt bob=(i,j)->i-j;
System.out.println("Sub two no = "+bob.sub(8, 2));
MulInt cob=(i,j)->i*j;
System.out.println("Mul two no = "+cob.prod(2, 2));
divInt dob=(i,j)->i/j;
System.out.println("div two no = "+dob.div(16, 2));
	}

}
