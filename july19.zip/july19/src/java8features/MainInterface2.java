package java8features;

@FunctionalInterface
interface CallInterface{
	void myCallMethod(String s);
}

public class MainInterface2 {

	public static void main(String[] args) {
		// using lambda expression
		CallInterface mon =(s)->
		System.out.println("Hello functional interface "+s);
		mon.myCallMethod("Hello");

	}
	

}
