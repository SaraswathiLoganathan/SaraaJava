package java8features;
interface Myinterface1
{
	void method1();
	default void message1() {
		System.out.println("MyInterface 1");
	}
}

interface Myinterface2
{
	void method2();
	default void message2() {
		System.out.println("MyInterface 2");
	}
}
class MessageClass implements Myinterface1,Myinterface2{

	@Override
	public void method2() {
		System.out.println("Method 1");
		
	}

	@Override
	public void method1() {
	System.out.println("Method 1");
		
	}
	
}
public class MultiInterface {
	public static void main(String args[]) {
		MessageClass ob=new MessageClass();
		ob.message1();
		ob.message2();
		ob.method1();
		ob.method2();
		
	}

}
