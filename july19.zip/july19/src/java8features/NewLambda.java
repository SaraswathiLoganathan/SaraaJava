package java8features;

interface Myinter{
	void dispaly(int i,String s);
}

public class NewLambda {

	public static void main(String[] args) {
		Myinter nob =(i,s)->{
		System.out.println("Age = "+i+" Name = "+s);
		System.out.println("hello");
		};
		nob.dispaly(25, "Saraa");
		
	}

}
