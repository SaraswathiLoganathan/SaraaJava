package navi.com;

import java.util.function.Function;

public class FunctionMain {

	public static void main(String[] args) {

       String s="Hello how are you?";
       //find the length of the string
       
       System.out.println("Length of the string="+s.length());
       
             Function<String, Integer> fob=(s1)->s.length();
             
             String s1="Hello how are you?";
             System.out.println("Calls Function use apply(length)"+fob.apply(s1));
             
	}

}
