package navi.com;

import java.util.function.Predicate;

public class MainPredicate {

	public static void main(String[] args) {
		// Predicate
		System.out.println("Predicste Example");
		
		Predicate<Integer>pob=(i)->(i>10);
		boolean val=pob.test(34);
		System.out.println("Return value = "+val);

	}

}
