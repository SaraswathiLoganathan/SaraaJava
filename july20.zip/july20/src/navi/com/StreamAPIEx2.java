package navi.com;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamAPIEx2 {

	public static void main(String[] args) {
		List<Integer> lst=new ArrayList<Integer>();
		
		for(int i=1;i<=100;i++) {
			lst.add(i);
			
		}
		
		System.out.println(lst);
		
		Stream<Integer> s=lst.stream();//to apply lambda exp,convert list to stream

		//filter the element greater than 75
		
		List<Integer> ls=s.filter(i->i>75).collect(Collectors.toList());
		System.out.println("Filtered Elements = "+ls);
		
		//or
		List<Integer> lst1=new ArrayList<Integer>();
		Iterator<Integer> it=lst.iterator();
		while(it.hasNext()) {
		int i=it.next();
		if(i>75) {
			lst1.add(i);
		}
	}
	System.out.println("New List = "+lst1);
}
}


