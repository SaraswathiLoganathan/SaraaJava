package assignment.ccom;

import java.util.Scanner;

public class Fibonacci {

	public static void main(String[] args) {
	/*	int a1,a2,a3,tm;
		a1=0;
		a2=1;
Scanner sc=new Scanner(System.in);
System.out.println("Enter value of number:");
 tm=sc.nextInt();
	}
public void Series() {
	System.out.println("Fibonacci Series");
	System.out.println(a1+" ");
	System.out.println(a2+" ");
	for(int i=1;i<=n-2;i++)
	{
		c=a+b;
		System.out.println(c+" ");
		a=b;
		b=c;
	}*/
}
}
