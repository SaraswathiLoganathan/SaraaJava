package assignment.ccom;

import java.util.Scanner;

public class LargestOfTwo {

	public static void main(String[] args) {
		int num1, num2;
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter the  two numbers:");
			num1=sc.nextInt();
			num2=sc.nextInt();
		}
		if(num1>num2) {
			System.out.println("Largest num ="+num1);
			
			
		}
		else if(num2>num1){
			System.out.println("Largest num ="+num2);
		}
		else {
			System.out.println("Both are equal");
		}
	}

}
