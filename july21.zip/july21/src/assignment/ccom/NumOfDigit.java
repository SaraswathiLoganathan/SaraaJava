package assignment.ccom;

class CountNum{
 int num,temp;
 int count=0;

  CountNum(int num){
	 this.num=num;
 }
 
public void CountDigit() {
	temp=num;
	while(temp>0) {
		temp=temp/10;
		count++;
	}
	System.out.println(+count);
	}
}
public class NumOfDigit {

	public static void main(String[] args) {
		
		}

}
