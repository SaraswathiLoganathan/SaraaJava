package assignment.ccom;

import java.util.Scanner;

public class PrimeOrNot {

	public static void main(String[] args) {
		
	}

}
/*public void generatePrime(){  //1 2 3 4 5 6.....    100
for(int i=1; i<=100;i=i+2){ //1 3 5 7 9.......99
c=0;
for(int j=1;j<=i;j++){ //1%1==0
        if(i%j==0){
            c++; //for prime count=2
       }
}
if(c==2){
   System.out.print(i+" ");
}
}

}
*/