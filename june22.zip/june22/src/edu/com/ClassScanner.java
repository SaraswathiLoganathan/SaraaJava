package edu.com;

import java.util.Scanner;

public class ClassScanner {

	public static void main(String[] args) {
		 String name;
		 int age;
		 float salary;
		
		//create an object Scanner
		Scanner sc = new Scanner(System.in);
		//dynamic initialization
		System.out.println("Enter Name");
		name = sc.nextLine();
		
		System.out.println("Enter age");
		age = sc.nextInt();
		
		System.out.println("Enter salary");
		salary =sc.nextFloat();

		System.out.println("your name="+name);
		System.out.println("your age="+age);
		System.out.println("your salary="+salary);
	}

}
