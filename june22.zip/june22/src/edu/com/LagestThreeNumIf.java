package edu.com;

import java.util.Scanner;

public class LagestThreeNumIf {

	public static void main(String[] args) {
		int num1, num2,num3, largest;
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter first numbers:");
			num1=sc.nextInt();
			System.out.println("Enter second numbers:");
			num2=sc.nextInt();
			System.out.println("Enter third numbers:");
			num3=sc.nextInt();
		largest=num1;
		if(num2>largest) {
			largest=num2;
		}
			if(num3>largest) {
			largest=num3;	
			}
			System.out.println("The largest number is "+largest);
		}

	}

}
