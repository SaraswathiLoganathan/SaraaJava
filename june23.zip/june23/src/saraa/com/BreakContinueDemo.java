package saraa.com;

import java.util.Scanner;

public class BreakContinueDemo {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int i;
		i=1;
		while(true) { //infinite loop
			System.out.println(i);
			i=i+1;
			System.out.println("to stop enter  n to continue any other char");
			char ch = sc.next().charAt(0);
			if(ch=='n') {
				//come out of the loop
				break;
			}
			else
			{
				continue;
			}
			
			
		}
		//after break;
		System.out.println("outside loop");
		
	}

}
