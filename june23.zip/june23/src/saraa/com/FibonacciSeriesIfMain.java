package saraa.com;

public class FibonacciSeriesIfMain {

	public static void main(String[] args) {
		
	}

}
