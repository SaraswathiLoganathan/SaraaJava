package saraa.com;

import java.util.Scanner;

public class FibonacciSeriesMam {

	public static void main(String[] args) {
		int terms,f1,f2,f3;
		f1=0;
		f2=1;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of terms:");
		terms=sc.nextInt();
		
		System.out.println("Fibonacci Series:");
		System.out.println(f1);
		System.out.println(f2);
		for(int i=3;i<=terms;i++) {
			f3=f1+f2;
			System.out.println(f3);
			f1=f2;
			f2=f3;
		}

	}

}
