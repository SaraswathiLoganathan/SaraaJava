package saraa.com;

import java.util.Scanner;

public class fatcorialMain {


	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num;
		double fact=1;
		System.out.println("Enter the number to find factorial");
		num=sc.nextInt();
		for(int i=num;i>=1;i--);{
		fact = fact *i;
		}
	}
}
	

