//Sum of n input array elements , find sum, max, min,average
package com.edu;

import java.util.Scanner;

public class Array {

	public static void main(String[] args) {
		int ar[],size,sum=0;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the size of an array");
		size = sc.nextInt();
		ar = new int[size];
		//input tye array elements
		System.out.println("Enter "+size+" of elements");
		for(int i=0;i<size;i++) {
			ar[i] = sc.nextInt();
		}
		System.out.println("Entered elements are");
		for(int i=0;i<size;i++) {
			System.out.println(ar[i]);
		}
		
		//find sum of all array elements
		for(int i=0;i<size;i++) {
			sum=sum+ar[i];
		}
		System.out.println("Sum of all array elements ="+sum);
		
		//largest of array elements
		
		int max=ar[0];
		for(int i=1;i<size;i++) {
			if(ar[i]>max) {
				max = ar[i];
			}
		}
		
		System.out.println("Largest element of an array is "+max);
		
		
		//least elements
		int min=ar[0];
		for(int i=1;i<size;i++) {
			if(ar[i]<min) {
				max = ar[i];
			}
		}
		
		System.out.println("Largest element of an array is "+max);
	}
}

