package com.edu;

public class ArrayDemoMain {

	public static void main(String[] args) {
		int ar[]= {3,7,8,9};
		for(int i=0;i<=ar.length;i++) {
			System.out.println(ar[i]);
		}

	}


}