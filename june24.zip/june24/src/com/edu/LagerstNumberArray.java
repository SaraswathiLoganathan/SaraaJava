package com.edu;

import java.util.Scanner;

public class LagerstNumberArray {

	public static void main(String[] args) {
		
			
				int ar[], size;
				Scanner sc = new Scanner(System.in);
				System.out.println("Enter a size of elements");
				size = sc.nextInt();
				ar= new int[size];
				int max = 0;
				
				for(int i=0; i<size; i++) {
					ar[i]=sc.nextInt();
					if(ar[i]>max) {
						max=ar[i];
					}
					
				}
				System.out.println("Max number is = "+max);
				
			}

		}