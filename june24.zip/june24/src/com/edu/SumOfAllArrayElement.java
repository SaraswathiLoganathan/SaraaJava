package com.edu;

import java.util.Scanner;

public class SumOfAllArrayElement {

	public static void main(String[] args) {
		int ar[],size,sum=0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of an array");
		size=sc.nextInt();
		ar=new int[size];
		System.out.println("Enter" +size+" of elements");
		for(int i=0;i<=size;i++) {
			ar[i]=sc.nextInt();
			sum=sum+ar[i];
		}
System.out.println(sum);
	}

}
