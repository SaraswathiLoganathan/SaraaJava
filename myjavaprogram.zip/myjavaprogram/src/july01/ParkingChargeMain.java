/*
 * Define a class named ParkingLot with the following description :
Instance variables/data members:
int vno � To store the vehicle number
int hours � To store the number of hours the vehicle is parked in the parking lot
double bill � Tb store the bill amount
Member methods:
void input( ) � To input and store the vno and hours.
void calculate( ) � To compute the parking charge at the rate of Rs.3 for the first hours or part thereof, 
and Rs. 1.50 for each additional hour or part thereof.
void display ( ) � To display the detail
Write a main method to create an object of the class and call the above methods.
 */

package july01;

import java.util.Scanner;

class parkingcharge{
	int vno,hrs;
	double bill;
	void input( ) {
		Scanner sc=new Scanner (System.in);
		System.out.println("Enter the Vehicle Number:");
		vno=sc.nextInt();
		System.out.println("Enter the Number of hrs:");
		hrs=sc.nextInt();
}
	void calculate() {
		//if(hrs<=1) {
		//	bill=hrs*3;
			
	//	}else {
	//		bill=3+((hrs-1)*1.5);
	//	}
		
		if(hrs==1) {
			bill= 3;
			
		}else {
			bill = 3;
			bill=bill+((hrs-1)*1.5);
		}
	}
		void display() {
			System.out.println("Vehicle Number: "+vno);
			System.out.println("Number of Hours: "+hrs);
			System.out.println("Bill Amount: "+bill);
			
		}
			
	}

public class ParkingChargeMain {

	public static void main(String[] args) {
		parkingcharge ob =new parkingcharge();
			ob.input();
			ob.calculate();
			ob.display();
		}
	}


