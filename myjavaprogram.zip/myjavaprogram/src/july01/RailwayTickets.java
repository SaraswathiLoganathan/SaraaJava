/*
  Design a class Railway Ticket with following description :
Instance variables/s data members :
String name : To store the name of the customer
String coach : To store the type of coach customer wants to travel
long mobno : To store customer�s mobile number
int amt : To store basic amount of ticket
int totalamt : To store the amount to be paid after updating the original amount

Member methods
void accept ( ) � To take input for name, coach, mobile number and amount
void update ( )� To update the amount as per the coach selected

Type of Coaches	  Amount
First_ AC	       700
Second_AC	       500
Third _AC	       250
sleeper	           None

void display( ) � To display all details of a customer such as name, coach, total amount and mobile number.
Write a main method to create an object of the class and call the above member methods.

 */


package july01;

import java.util.Scanner;
  
class RailwayTicket {
	
	 String name;
	 String coach;
	 long mobno;
	 int amt;
	 int tamt;
	
	void UserInput() {
		Scanner sc =new Scanner(System.in);
		 System.out.println("Customer name: ");
		 name = sc.nextLine();
		 System.out.print("Enter coach: ");
	       coach = sc.nextLine();
	        System.out.print("Enter mobile no: ");
	        mobno = sc.nextLong();
	        System.out.print("Enter amount: ");
	        amt = sc.nextInt();
	}
	
	void update() {
		if(coach.equalsIgnoreCase("First_Ac")) {
			tamt=amt+700;
			
		}
		else if(coach.equalsIgnoreCase("Second_Ac")) {
			tamt=amt+500;
			
		}
		else if(coach.equalsIgnoreCase("Third-Ac")) {
			tamt=amt+250;
			
	}
		else if(coach.equalsIgnoreCase("Sleeper")) {
			tamt=amt;	
			
}else {
	System.out.println("Invalid input");
}
	}
	void dispaly() {
		System.out.println("Name : "+name);
		System.out.println("Coach : "+coach);
		System.out.println("mobile number : " +mobno);
		System.out.println("Amonut : "+amt);
		System.out.println("Total Amount : "+tamt);

	}
	}

public class RailwayTickets {

	public static void main(String[] args) {
		RailwayTicket ob=new RailwayTicket();
		ob.UserInput();
		ob.update();
		ob.dispaly();
	}

}
