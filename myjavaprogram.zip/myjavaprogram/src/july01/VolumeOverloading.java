/*
 * Design a class to overload a function volume() as follows : 
(i) double volume (double R) � with radius (R) as an argument, returns the volume of sphere using the formula.
V = 4/3 � 22/7 � R3
(ii) double volume (double H, double R) � with height(H) and radius(R) as the arguments, returns the volume of a cylinder using the formula.
V = 22/7 � R2 � H
(iii) double volume (double L, double B, double H) � with length(L), breadth(B) and Height(H) as the arguments, returns the volume of a cuboid using the formula.
L*B*H

 */

package july01;
class VolumeofOverloading{
	
	double volume(double r) {
		double vol =(4/3)*(22/7)*(r*r*r);
	//	System.out.println("Volume of a sphere is "+vol);
		return vol;
	}
	
	double volume(double h, double r){
		double v=(22/7)*(r*r)*h;
		return v;
	}
	
	double volume(double l, double b,double h){
		//double cv=l*b*h;
		return l*b*h;
}
}

public class VolumeOverloading {

	public static void main(String[] args) {
		VolumeofOverloading ob = new VolumeofOverloading();
		//ob.vol();
		//double v=vob.volume(4);
		//System.out.println("volume of a sphere is "+v);
		System.out.println("volume of a sphere is "+ob.volume(2));
		System.out.println("volume of a Cylinder is "+ob.volume(4, 6));
		System.out.println("Volume of cuboid is "+ob.volume(2, 4, 7));

	}
}

