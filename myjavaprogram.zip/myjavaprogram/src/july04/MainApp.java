package july04;
 class ConstructorClass {
    int id;
    String name;
	public ConstructorClass(int id, String name) {
	
	this.id = id;  // this refers to persent object
	this.name = name;
	}
	
	void display() {
		System.out.println("Id="+id);
		System.out.println("Name="+name);
	}
     
 }

public class MainApp {

	public static void main(String[] args) {
	     ConstructorClass ob=new ConstructorClass(34, "Saraswathi");
	     ob.display();
	     
	     
	}

}
