package july05;

abstract class Abstractclass  {
	void display() {
		System.out.println("Dispaly mothod");
	}
}

public class AbstactMethod extends Abstractclass {
	public static void main(String[] args) {
		AbstactMethod ob= new AbstactMethod();
		ob.display();
		}

}
