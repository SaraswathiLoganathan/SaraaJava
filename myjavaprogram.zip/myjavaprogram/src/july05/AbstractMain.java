package july05;

abstract class AbstractClass1{
	private int pdata;
	public AbstractClass1(int pdata) {
		System.out.println(pdata+30);
	}
}
class ChildClass extends AbstractClass1{
	public ChildClass(int pdata) {
		super(pdata);
	}
}

public class AbstractMain {

	public static void main(String[] args) {
		ChildClass ob=new ChildClass(55);

	}

}
