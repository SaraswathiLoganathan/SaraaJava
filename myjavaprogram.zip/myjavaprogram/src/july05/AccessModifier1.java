package july05;

public class AccessModifier1 {
    private int privateval;
    public int publicval;
    int dfaultval;//default
    protected int protetedval;
    
   public AccessModifier1() {
	   privateval=10;
	   publicval=98;		
	   dfaultval=78;
	   protetedval=12;
	}
    
    public void method1() {
    	System.out.println("n="+privateval);
    }
}


