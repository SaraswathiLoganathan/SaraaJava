package july05;

abstract class Bank{
	abstract float rateOfInterset();
	void dispaly() {
		System.out.println("Display method");
	}
}
class SBI extends Bank{
	float rateOfInterset() {
		return 7.5f;
	}
}
class HDFC extends Bank{
	float rateOfInterset() {
		return 9.7f;
	}
}
public class BankAbstract {

	public static void main(String[] args) {
		SBI ob=new SBI();
		System.out.println("Rate of interset of SBI="+ob.rateOfInterset());
		ob.dispaly();
		HDFC hb=new HDFC();
		System.out.println("Rate of interset of SBI="+hb.rateOfInterset());
hb.dispaly();
	}

}
