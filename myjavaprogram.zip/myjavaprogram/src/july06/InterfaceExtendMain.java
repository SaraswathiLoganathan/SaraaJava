package july06;

interface One{
	void m1();

}
interface Two{
	void m2();
}

interface Three extends One, Two{
	void m3();
}

class Hello{
	
}
class Hi{
	
}
class IntClass extends Hello implements Three{

	@Override
	public void m1() {
		System.out.println("M1");
		
	}

	@Override
	public void m2() {
			System.out.println("M2");
	}

	@Override
	public void m3() {
		System.out.println("M3");
		
	}
	
}
public class InterfaceExtendMain {

	public static void main(String[] args) {
		  IntClass ob=new IntClass();
         ob.m1();
         ob.m2();
         ob.m3();

	}

}
