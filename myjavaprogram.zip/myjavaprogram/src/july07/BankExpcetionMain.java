package july07;

class BankException extends Exception{
	  public BankException(String s) {
		  super(s);
	  }
}


class Bank{
	public void checkBalance(int amount){
		if(amount<10000) {
			try {
				//throw new AgeCheckException("not eligible for voting");
				BankException erob=new BankException("not Withdraw the amount");
				throw erob;
			}catch(BankException e)
			{
				e.printStackTrace();
			}
			
		}else {
			System.out.println("Withdraw the amount");
		}
	}
}

public class BankExpcetionMain {

	public static void main(String[] args) {
		Bank vob=new Bank();
		vob.checkBalance(10000);
	}

}

