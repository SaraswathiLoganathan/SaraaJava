//Local inner class is a class written inside a method of outer class
package july08;

class OuterClassLocal{
	void outerMethodLocal() {
		class LocalInnerClass{
			void localInnerMethod() {
				System.out.println("Local Innermethod");
			}
			
		}
		LocalInnerClass innerobj=new LocalInnerClass();
		innerobj.localInnerMethod();
	}
}

public class LocalInnerMain {

	public static void main(String[] args) {
		OuterClassLocal outerobj=new OuterClassLocal();
		outerobj.outerMethodLocal();
	}

}
