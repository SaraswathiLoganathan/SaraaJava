//class inside another class innerclass
package july08;

class OuterClass{
	int i, j;
	
	public OuterClass() {
		i=10;
		j=50;
	}
	
	class InnerClass{
		void innerMathod() {
			System.out.println("sum="+(i+j));
		}
	}
	
	void outerMethod() {
		System.out.println("Outer method");
		InnerClass innerob=new InnerClass();
		innerob.innerMathod();
	}
}

public class MainInnerApp {

	public static void main(String[] args) {
		OuterClass outerobj=new OuterClass();
		outerobj.outerMethod();

	}

}
