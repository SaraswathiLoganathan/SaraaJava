package july08;

public class Sade {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
