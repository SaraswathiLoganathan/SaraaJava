//static inner class , only inner class can be static
package july08;
 class MyOuterClass{
	static class InnerStatic{
		 void innerFunction() {
			 System.out.println("static class method");
		 }
	}
}

public class StaticInnerClassMain {

	public static void main(String[] args) {
		MyOuterClass.InnerStatic ob=new MyOuterClass.InnerStatic();
		ob.innerFunction();
	}

}
