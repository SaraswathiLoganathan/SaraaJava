package july09;

import java.util.ArrayList;
import java.util.Iterator;



public class CollectionsArrayDemo {

	public static void main(String[] args) {
		
		// Dynamic Array
		ArrayList<Integer> ob =new ArrayList<Integer>();
		ob.add(211);
		ob.add(342);
		ob.add(73);
		ob.add(45);
		
		//for dispaly
		System.out.println("Integer "+ob);
		
		//for each //enhanced
		for(int i:ob) {//for(datatype var_name : object_name)
			System.out.println(i);
		}
		

		Iterator<Integer> iy=ob.iterator();
		while(iy.hasNext()) {
			System.out.println(iy.next());
		}
		
		ArrayList<Float>oc=new ArrayList<Float>();
		oc.add(98.6f);
		oc.add(13.4f);
		oc.add(45.7f);
		oc.add(78.4f);
		System.out.println("Float Values="+oc);
	
		for(float k:oc) {
			System.out.println(k);
		}

		Iterator<Float> ii=oc.iterator();
		while(ii.hasNext()) {
			System.out.println(ii.next());
		}
		
		
		ArrayList<Double>od=new ArrayList<Double>();
		od.add(33.632);
		od.add(32.423);
		od.add(131.72);
		od.add(332.422);
		System.out.println("Double Values="+od);
		
		for(double e:od) {
			System.out.println(e);
		}
		//Using Iterator fetch the data
				Iterator<Double> it=od.iterator();
				while(it.hasNext()) {
					System.out.println(it.next());
				}
		
		ArrayList<String>os=new ArrayList<String>();
		os.add("Saraa");
		os.add("Navvi");
		os.add("Dharani");
		os.add("Saran");
		System.out.println("String Values="+os);
		
		for(String q:os) {
			System.out.println(q);
		}
		
		Iterator<String> ig=os.iterator();
		while(ig.hasNext()) {
			System.out.println(ig.next());
		}
		
		
		
		
}
}
