package july11;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;

public class MainLinkedList {

	public static void main(String[] args) {
		LinkedList<String> lob=new LinkedList<String>();
		lob.add("Navvi");
		lob.add("Priya");
		lob.add("Saraa");
		lob.add("Saran");
		System.out.println(lob);
		lob.remove(1);
		System.out.println(lob);
		LinkedList<String> lob1=new LinkedList<String>();
		lob1.add("One");
		lob1.add("Two");
		lob1.add("Three");
		lob1.add("Four");
		lob.addAll(lob1);
		lob1.add("Five");
		System.out.println(lob);
		System.out.println("Saraa is present "+lob.contains("Saraa"));
		System.out.println(lob.containsAll(lob1));
		System.out.println(lob.indexOf("Saran"));
		
		//Iterate elements using iterator
		Iterator<String> it=lob.iterator();
		while(it.hasNext()) {
		System.out.println(it.next());
	}

	//using for-each or enhanced for
	
	for(String s:lob) {
		System.out.println(s);
	}
	
	//Sorting
	Collections.sort(lob);
	System.out.println("Sorted Element");
	System.out.println(lob);
	
	Collections.shuffle(lob);
	System.out.println("After Shuffle"+lob);

	Collections.swap(lob,1, 3);
	System.out.println("after swap "+lob);

	}
}