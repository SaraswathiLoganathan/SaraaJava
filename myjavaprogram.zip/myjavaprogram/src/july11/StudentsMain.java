package july11;


import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;

class Student{
	 int sid;
     String sname;
	 int sage;
     float sfees;
	
	public Student(int sid, String sname, int sage, float sfees) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.sage = sage;
		this.sfees = sfees;
	}

	
	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + ", sage=" + sage + ", sfees=" + sfees + "]";
	}
	
}
class StudentSageSort implements Comparator<Student>{

	@Override
	public int compare(Student o1, Student o2) {
		if(o1.sage>o2.sage) {
		return 1;
	}else if(o1.sage==o2.sage) {
		return 0;
		
	}else {
		return -1;
	}
}
	
}
public class StudentsMain {

	public static void main(String[] args) {
		Student s1=new Student(1, "Sneha", 17, 876.3f);
		Student s2=new Student(2, "Manoj", 19, 8761.3f);
		Student s3=new Student(3, "Neha", 20, 986.3f);
		Student s4=new Student(4, "Anu", 15, 1876.3f);

		LinkedList<Student> slist=new LinkedList<Student>();
		slist.add(s1);
		slist.add(s2);
		slist.add(s3);
		slist.add(s4);
		
		System.out.println(slist);
		
		//iterator
		Iterator<Student> sit=slist.iterator();
		
while(sit.hasNext()) {
			Student s=sit.next();
			System.out.println(s.sid+"\t"+s.sname+"\t\t"+s.sage+"\t"+s.sfees);
		}
StudentSageSort ob=new StudentSageSort();
Collections.sort(slist,ob);
//Collections.sort(slist,new StudentSageSort());
		
	}
}
