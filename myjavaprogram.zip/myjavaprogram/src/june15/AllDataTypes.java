package june15;

public class AllDataTypes {

	public static void main(String[] args) {
		int num = 1;
		short snum = 43;
		byte bnum =-127;
		boolean onum =true;
		long lnum = 456;
		float fnum = 45.00f;
		double dnum = 59.55;
		char ch = 'S';
		String txt = "Hello World";// string datatype
		String[] cars = {"Volvo", "BMW", "Ford", "Mazda"};//Array datatype 
		
		System.out.println(cars[1]);
	    System.out.println(txt.toUpperCase());
	    System.out.println(txt.toLowerCase());
	    System.out.println(num);
	    System.out.println(snum);
	    System.out.println(bnum);
	    System.out.println(onum);
	    System.out.println(lnum);
	    System.out.println(fnum);
	    System.out.println(dnum);
	    System.out.println(ch);
	 /*   AllDataTypes.sum(num);
	    AllDataTypes newobj = new AllDataTypes();
	    newobj.sumone(ch, bnum);
	    
	}

	public static int sum(int a) 
	{
		a =18;
		int b =2;
		
		return a;
	}
	
	public static int sum(int a,int b) 
	{
		a =18;
		 b =2;
		
		return a;
	}
	
	public  int sumone(int a,int b) 
	{
		a =18;
		 b =2;
		
		return a;*/
	}
}

