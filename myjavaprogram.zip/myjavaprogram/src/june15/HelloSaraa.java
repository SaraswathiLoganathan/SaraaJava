package june15;

public class HelloSaraa {

	public static void main(String[] args) {
		System.out.println("I am Saraa");
		System.out.println("I am MCA");

	}

}
