package june15;

public class Source {

	public static void main(String[] args) {

		Source ob =new Source();
		
		System.out.println(ob.retString());
		
		SourceSubClass oc= new SourceSubClass();
		
		System.out.println(oc.retString());
		
	}

	public String retString() {
		
		return "Parent";
	}

}
class SourceSubClass extends Source{
	
public String retString() {
		
		return "Child";
	}
}
