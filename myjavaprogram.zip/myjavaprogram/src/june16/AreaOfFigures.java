//Program to find area or Square, Reactangle, Circle, Triangle
package june16;

public class AreaOfFigures {

	public static void main(String[] args) {
		

		double length,breadth,side,radius,pi,area,base,height;
		length=56.7;
		breadth=78.4;
		side=84.7;
		radius=23;
		pi=3.14159;
		area=2.4;
		base=6;
		height=3;
		
		area=side*side;
		System.out.println("Area of Square of side="+side+"is"+area);
		
		area=length*breadth;
		System.out.println("Area of Reactengle of length="+length+"and breadth="+breadth+"is"+area);
		
		area=pi*radius*radius;
		System.out.println("Area of circle of radius="+radius+"is"+area);
		
	}

}