//Program to Demonstrate about variables and datatype displaying them
package june16;

public class DataTypeVariables {

	public static void main(String[] args) {
		int num; //declaration
		num=10; //static initialization (initialization)
		//int myvar; //no garbage value
		//or int num=10;
		float fval=67.78f;
		double dval=87.45;
		char ch='S';
		String s="SARAA";
		System.out.println("int num="+num);//printf("int num =%d",num);
		System.out.println("float fval="+fval);
		System.out.println("double dval="+dval);
		System.out.println("char ch="+ch);
		System.out.println("String value s="+s);
		//System.out.println(myvar);
	}
}
