package june16;

public class MathematicalOperations {

	public static void main(String[] args) {
		int num1,num2,sum,sub,prod; //declaration
		float div, mod;     //declaration
		num1=15;         //static initialization
		num2=51;
		
		//find the sum
		sum=num1+num2; //+
		System.out.println("The sum of "+num1 +" and "+num2 +" is "+sum);
		sub=num2-num1;
		
		System.out.println("The difference of "+num2+" and "+num1+" is "+sub);
		
		prod=num1*num2;
		System.out.println("The prod of "+num1+" and "+num2+" is "+prod);
		
		div=(float)num2/num1;
		System.out.println("The quotient of "+num2+" and "+num1+" is "+div);
		
		mod=num2%num1;
		System.out.println("The Remainder of "+num2+" and "+num1+" is "+mod);

	}

}
