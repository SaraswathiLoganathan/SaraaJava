//write a program to check the given is even or odd
package june17;

import java.util.Scanner;

public class CheckNumber {

	public static void main(String[] args) {
		int num;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number");
		num = sc.nextInt();
        if(num==0) {
        	System.out.println(num+ " is equal to zero");
        }
        else if(num>0) 
        {
        	System.out.println(num+ " is greater than zero");
        }
        else
        	System.out.println(num+ " is less than zero");
        }
        }




