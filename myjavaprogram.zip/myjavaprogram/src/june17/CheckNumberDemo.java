package june17;

import java.util.Scanner;

public class CheckNumberDemo {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			System.out.print("Input a number: ");
	        int n = sc.nextInt();

	        if (n > 0)
	        {
	            System.out.println("Number is positive");
	        }
	        else if (n < 0)
	        {
	            System.out.println("Number is negative");
	        }
	        else
	        {
	            System.out.println("Number is zero");
	        }
		}
	}
}

