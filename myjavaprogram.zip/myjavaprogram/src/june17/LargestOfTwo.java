package june17;

import java.util.Scanner;

public class LargestOfTwo {

	public static void main(String[] args) {
		int first, second,large;
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter the  two numbers:");
			first=sc.nextInt();
			second=sc.nextInt();
		}
		if(first>second) {
			System.out.println("Largest of "+first+" and "+second+" is "+first);
			
			
		}
		else {
			System.out.println("Largest of "+first+" and "+second+" is "+second);
		}

	}

}
