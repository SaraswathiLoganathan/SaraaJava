//accept data and display
package june17;

import java.util.Scanner;

public class UserInputDataMain {

	public static void main(String[] args) {
		//declaration of variables
		String name;
		int age;
		float fees;
		double amount;
		char gen;
      //create an Object
		int r;
		//System.in->input device(Keyword)
		Scanner sc = new Scanner(System.in);{//Scanner class , sc->user defined object
		//int ->nextInt(), float->nextFloat(), double->nextDouble()
		//long->nextLong()
		//String name=next()->read word
		//String with the space nextLine()
		//char ->next().charAt(0);
		
		//System.out(Monitor) display purpose
		
		System.out.println("Enter name"); //System->class out->object  println->function
		name=sc.nextLine();
		System.out.println("Enter age");
		age = sc.nextInt();
		System.out.println("Enter fees");
		fees = sc.nextFloat();
		System.out.println("Enter totla amount");
		amount = sc.nextDouble();
		System.out.println("Enter gender m/f");
		gen=sc.next().charAt(0);
}
	System.out.println("Your details are");
	System.out.println("Name: "+name);
	System.out.println("Age: "+age);
	System.out.println("Fees: "+fees);
	System.out.println("Amount: "+amount);
	System.out.println("Gender: "+gen);
}
}