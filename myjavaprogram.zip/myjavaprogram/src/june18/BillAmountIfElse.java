package june18;

import java.util.Scanner;

public class BillAmountIfElse {

	public static void main(String[] args) {
          String cname;
          int  units;
          float bamount;
          
		
         Scanner sc = new Scanner(System.in); {
			
        	System.out.println("Enter Consumer Name:");
			cname = sc.nextLine();
			
			System.out.println("Enter number of units:" );
			units = sc.nextInt();
         
		 
			if(units <= 0) {
				System.out.println("Number of units should not be zero or negative");
				System.exit(0);
				
			}

		 if(units >=1 && units <= 100){
        	bamount = units*2.0f;
		 }
		 else if(units >= 101 && units >=100) {
			 bamount = 100*2.0f+(units-100)*3.0f;
		 }
		 else {
			 bamount = 100*2.0f+(units-100)*3.0f+(units-300)*5.0f;
			 bamount = bamount+(bamount*2.5f)/100;
		 }
		 
        System.out.println("Name="+cname);
        System.out.println("Units="+units);
        System.out.println("bamount="+bamount);
         

         }
	}
}

