//Program to find largest of 3 numbers using else if ladder

package june18;

import java.util.Scanner;

public class LargestofThreeIfElse {

	public static void main(String[] args) {
		int first, second, third;
		
        try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter 3 numbers");
			first = sc.nextInt();
			second = sc.nextInt();
			third = sc.nextInt();
		}
        
        if(first >= second && first >= third) {
        	System.out.println("The largest of "+first+" ,"+second+" and "+third+" is "+first);
        }
        else if(second >= first && second >= third) {
        	System.out.println("The largest of "+first+" ,"+second+" and "+third+" is "+second);
        }
        else {
        	System.out.println("The largest of "+first+" ,"+second+" and "+third+" is "+third);
        }
        				
	}
	
}



