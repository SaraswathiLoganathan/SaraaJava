package june20;

import java.util.Scanner;

public class EvenOrOddSwitchCase {

	public static void main(String[] args) {
		 Scanner sn = new Scanner(System.in);

		    int number = 0;

		    System.out.printf("Enter the number: ");
		    number = sn.nextInt();

		    switch (number % 2) {
		    case 0:
		      System.out.printf("%d is an even number.\n", number);
		      break;

		    case 1:
		      System.out.printf("%d is an odd number.\n", number);
		      break;
		    }

	}

}
