package june21;

import java.util.Scanner;

class ArmstrongNumber{
	int num, temp;
	void dataInput() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number");
		num=sc.nextInt();
		
	}
	
	void checkArmstrong() {
		//ex : 153=1*1*1+5*5*5+3*3*3 or 153 = 3*3*3+5*5*5+1*1*1
		temp=num;
		int digit=0;
		int s=0;
		while(temp>0) {
			digit = temp%10;
			s=s+(digit*digit*digit); //0+27  //s=27+125=152 //s=152+1=153
			temp=temp/10;
		}
		
		if(num==s) {
			System.out.println(num+" is armstrong number");
		}
		else {
			System.out.println(num+" is not armstrong number");
		}
	}
}

public class ArmstrongNumberIfElse {

	public static void main(String[] args) {
		ArmstrongNumber armobj = new ArmstrongNumber();
		armobj.dataInput();
		armobj.checkArmstrong();

	}
}
