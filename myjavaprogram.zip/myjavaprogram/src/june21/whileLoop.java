package june21;

public class whileLoop {

	public static void main(String[] args) {
		int i; 
        String name="Saraa"; 
         
        i=1; 
        while(i<=10){
            System.out.println(name);
            i++; 
        }
	}
}
