package june22;

import java.util.Scanner;

public class LargestTwoNumTest {

	public static void main(String[] args) {
		int num1, num2;
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter first numbers:");
			num1=sc.nextInt();
			System.out.println("Enter second numbers:");

			num2=sc.nextInt();
		}
		if(num1>num2) {
			System.out.println(num1+" is largest" );
			
			
		}
		else {
			System.out.println(num2+" is largest");
		}

	}

}
