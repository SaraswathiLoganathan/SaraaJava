package june22;

public class VariableDataTypeTest {

	public static void main(String[] args) {
		int num1,num2,sum;  //int keyword, num1, num2, sum are identifiers
		num1=45; //static initialization
		num2=34;
		sum=num1+num2; //expression
		
		System.out.println("sum="+sum);
		
		
		

	}

}
