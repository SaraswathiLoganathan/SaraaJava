package june22;
import java.util.Scanner;

public class VariableScannerTest {

	public static void main(String[] args) {
		
				int num1=0,num2=0,sum=0;  //int keyword, num1, num2, sum are identifiers
				
				//create an object Scanner
				Scanner sc = new Scanner(System.in);
				//dynamic initialization
				System.out.println("Enter first number");
				num1 = sc.nextInt();
				
				System.out.println("Enter second number");
				num2 = sc.nextInt();
				
				sum=num1+num2; //expression
				
				System.out.println("sum="+sum);
				
				
			

	}

}
