package june23;

public class DoWhileLoopEx {

	public static void main(String[] args) {
		int i=1;
		while(i>1){
			System.out.println("While "+i);
		}
		do {
			System.out.println("do while "+i);
		}
		while(i>1);
	}

}
