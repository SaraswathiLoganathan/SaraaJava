package june23;

public class FactorsWhile {

}
