package june23;

public class IncrementDemo {

	public static void main(String[] args) {
		int a = 3,b = 4,c;
		c = a + b + b++ + b++ + ++a + ++b;
		System.out.println(c);
}
}