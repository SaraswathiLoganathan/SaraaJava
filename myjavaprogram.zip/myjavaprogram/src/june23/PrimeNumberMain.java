package june23;

import java.util.Scanner;

public class PrimeNumberMain {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num, c=0;
		System.out.println("Enter a number to find prime");
		num =sc.nextInt();
		
		for(int i=1;i<=num;i++)
		{
			if(num%i==0) {
				c++;
			}
		}
		if(c==2) {
			System.out.println(num+" is prime number");
		}
		else {
			System.out.println(num+" is not prime ");
		}
	}

}
