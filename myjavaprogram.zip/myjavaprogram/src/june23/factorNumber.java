package june23;

import java.util.Scanner;

public class factorNumber {
  public static void main(String[]args) {
Scanner sc= new Scanner(System.in);

int num;
System.out.println("Enter the number to find factors");
	num=sc.nextInt();
for(int i=1;i<=num;i++) {
	if(num%i==0) {
		System.out.println(i);
		
		
		/*int=i;
	i= num;
	while(i>=1) {
		fact = fact *i;
		i--;
	}*/
	System.out.println("Factorial ="+i);

	}
}
  
  }
}
  
