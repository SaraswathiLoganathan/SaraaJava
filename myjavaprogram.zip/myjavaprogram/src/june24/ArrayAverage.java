package june24;

import java.util.Scanner;

public class ArrayAverage {

	public static void main(String[] args) {
		int ar[],size,sum=0,i,avg;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a size of elements:");
		size =sc.nextInt();
		ar=new int[size];
		System.out.println("Enter array elements "+ar.length);

		for( i=0; i<ar.length; i++) {
			ar[i]=sc.nextInt();
		}
		System.out.println("Array elements are");
		for(i=0;i<ar.length;i++) {
			System.out.println(ar[i]);
			sum=sum+ar[i];
	}
		System.out.println("Sum of array is "+sum);
		avg=sum/size;
		System.out.println("Average is "+avg);

}
}
