package june24;

public class ArrayDemoMain {

	public static void main(String[] args) {
		int ar[]= {3,7,8,9};
		
			System.out.println(ar[3]);
		}

	
}


