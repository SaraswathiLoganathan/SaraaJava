package june24;

import java.util.Scanner;

public class ArrayMinNum {

	public static void main(String[] args) {
		int ar[],size,i;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a size of elements:");
		size =sc.nextInt();
		ar=new int[size];
		System.out.println("Enter array elements "+ar.length);

		for( i=0; i<ar.length; i++) {
			ar[i]=sc.nextInt();
		}
		System.out.println("Array elements are");
		for(i=0;i<ar.length;i++) {
			System.out.println(ar[i]);

	}
		int min=ar[0];
		for(i=1;i<ar.length;i++) {
			if(ar[i]<min) {
				min=ar[i];
			}
		
		
	}
	System.out.println("Min number is = "+min);
	
	}
}
