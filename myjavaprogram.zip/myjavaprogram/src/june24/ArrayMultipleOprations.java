package june24;

class ArrayOperation{
	int ar[],size,i,sum,avg;
	public void inputdata() {
}
public class ArrayMultipleOprations {

	public static void main(String[] args) {

	}

}
}