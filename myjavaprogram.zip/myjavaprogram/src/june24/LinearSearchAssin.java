package june24;

import java.util.Scanner;

public class LinearSearchAssin {

	public static void main(String[] args) {
		int limit,i,key;
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter the limit Number");
		limit=sc.nextInt();
		int array[] = new int[limit];
		System.out.println("Enter " +limit + " numbers:");  
		   
	    for (i = 0; i < limit; i++)  
	      array[i] = sc.nextInt();  
	   
	    System.out.println("Enter the search element:");  
	    key = sc.nextInt();  
	   
	    for (i = 0; i < limit; i++)  
	    {  
	      if (array[i] == key)      
	      {  
	         System.out.println("The search element "+ key +" is found at location "+ (i+1));
	          break;  
	      }  
	   }  
	   if (i == limit)  
	      System.out.println("The search element "+ key +" is not found");
	}

}
