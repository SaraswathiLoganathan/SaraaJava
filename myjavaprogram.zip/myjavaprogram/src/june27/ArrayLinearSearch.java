package june27;

import java.util.Scanner;

class ArrayOperationLinearSearch{
	int arr[], size, key;
	
	public void inputData() {
		
		Scanner sc=new Scanner(System.in);
	    System.out.println("Enter size of an array");
	    size = sc.nextInt();
	    arr=new int[size];
	    System.out.println("Enter the "+size+" array elements");
	    System.out.println("Enter array elements");
	    for(int i=0;i<size;i++) {
	    	arr[i] = sc.nextInt();
	    }
	    
	    System.out.println("Enter key element to search");
	    key = sc.nextInt();
	   
	}
	
	public void displayElements() {
		System.out.println("Array elements are ");
		for(int i=0;i<size;i++) {
			System.out.println(arr[i]);
		}
	}

	//Search an element using Linear Search 
	public void linearSearch() {
		int pos=-1;
		for(int i=0;i<size;i++){
		    if(key==arr[i]){
		        pos=i;
		        break;
		    }
		}
		if(pos>=0) {
			System.out.println("Successful search");
			   System.out.println(key+" found at position "+(pos+1));

		}
else{
			System.out.println("Unsuccessful search");
			System.out.println("Element is not found");
		}
	}
}
public class ArrayLinearSearch {

	public static void main(String[] args) {
		ArrayOperationLinearSearch search = new ArrayOperationLinearSearch();
		search.inputData();
		search.linearSearch();
		search.displayElements();
		
	}
}
