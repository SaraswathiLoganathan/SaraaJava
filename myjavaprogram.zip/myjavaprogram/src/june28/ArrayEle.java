package june28;

public class ArrayEle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
