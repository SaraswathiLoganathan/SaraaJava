package june29;

public class CountCharacterString {

	public static void main(String[] args) {
		 String s = "I am saraswathi from chennai";    
	        int count = 0;    
	            
	        for(int i = 0; i < s.length(); i++) {    
	            if(s.charAt(i) != ' ')    
	                count++;    
	        }    
	              
	        System.out.println("Number of characters in a string: " + count);    
	    }    
	}     


