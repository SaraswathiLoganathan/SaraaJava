package june29;

public class CountWordsString {
	public static void main(String[] args){
		
		String s = "I am saraswathi from chennai"; 
          int numcount = 1;
 
        for (int i = 0; i < s.length() - 1; i++){
        	 if ((s.charAt(i) == ' ') && (s.charAt(i + 1) != ' '))
            numcount++;
            
        }
        System.out.println("Number of words : " + numcount);
}
}