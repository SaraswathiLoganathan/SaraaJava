package june29;

public class IndexFunString {

	public static void main(String[] args) {
	
		String s="Mahathma Karamchandh Gandhi";
	System.out.print(s.charAt(0)+".");
	int b1=s.indexOf(' ');
	System.out.print(s.charAt(b1+1)+".");
	int b2=s.lastIndexOf(' ');
	System.out.print(s.charAt(b2+1)+"andhi");
	}

}
