package june29;

import java.util.Scanner;

public class ReversMainString {
	public static void main(String[] args) {
		String s;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String ");
		s=sc.nextLine();
		// hello
		// 01234
		for(int i=s.length()-1; i>=0;i--) {
			System.out.print(s.charAt(i));
		}
	}

}
