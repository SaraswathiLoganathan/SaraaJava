package june29;

public class StringMainDemo {

	public static void main(String[] args) {
		String s ="Hello";
		String s1 ="Hello";
		
		String s2 = new String("Hello");
		String s3 = new String("Hello");
		
		if(s==s1) {
			System.out.println("s and s1 has same address");
		}else
		{System.out.print("s and s1 dont has different info");
		
		}
		if(s1.equals(s2)) {
			System.out.println("s1 and s2 has same address");
		}else
		{System.out.print("s1 and s2 dont has different info");
		
		}
		if(s2==s3) {
			System.out.println("s2 and s3 has same address");
		}else
		{System.out.print("s2 and s3 dont has different info");
		
		}
		if(s2.equals(s3)) {
			System.out.println("s2 and s3 has same address");
		}else
		{System.out.print("s2 and s3 dont has different info");
		
		}
		
	}

}
