package june29;

import java.util.Scanner;

public class ValidDataUserMain {

	public static void main(String[] args) {
		String un,pass;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the user name");
		un = sc.next();
		System.out.println("Enter the password");
		pass = sc.next();
		if(un.equalsIgnoreCase("saraa")&&pass.equals("saraa123")) {
		System.out.println("User is Valid");	                       
		}else {
			System.out.println("User is not valid");
		}
		}

}
