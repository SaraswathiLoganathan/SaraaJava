package june30;

public class ConstructorDemo {
	int a,b,s; //instance variables
	//Constructor is a special method , its name is class name itself and it does not 
	//have return type
	 ConstructorDemo(){ //constructor
		a=10;
		b=56;
		System.out.println("Constructor is called");
		System.out.println("Constructor is used to initialize the member data of the class");
	}
	void add() {//method
		s=a+b;
		System.out.println("s="+s);
	}

	public static void main(String[] args) {
		ConstructorDemo ob = new ConstructorDemo();//calls constructor
		ob.add(); //calling methods
	}
}
