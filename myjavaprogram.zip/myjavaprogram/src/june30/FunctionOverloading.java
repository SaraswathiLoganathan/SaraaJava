package june30;
class Overloading{
	void dispaly() {
		System.out.println("one arg function");
	}
	void dispaly(int i) {
		System.out.println("one arg function of type int");
	}
	void dispaly(float i) {
		System.out.println("one arg function of type float");
	}
	void dispaly(double i) {
		System.out.println("one arg function of type double");
	}
	void dispaly(char i) {
		System.out.println("one arg function of type char");
	}
	void display(int i, int j) {
		System.out.println("two arg of type int");
	}
	void display(int i, float j) {
		System.out.println("two arg one is int and another is float");
	}
	void display(float j, int i) {
		System.out.println("By interchanging arguments first is float and second is int");
	}
	void display(short i, short j) {
		System.out.println("Two short "+ i+j);
	}
}



public class FunctionOverloading {

	public static void main(String[] args) {
		Overloading ob=new Overloading();
		ob.dispaly();
		ob.dispaly(33);
		ob.dispaly(3.5f);
		ob.dispaly(4.7);
		ob.dispaly('S');
		ob.display(7,4);
        ob.display(8, 7.9f);
        ob.display(4.3f, 9);
        ob.display((short) 8, (short) 4);

	}

}
