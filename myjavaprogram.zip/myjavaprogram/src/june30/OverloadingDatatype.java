package june30;

class Overload{
	void add(int i,int j) {
		
		System.out.println("Add int value " + (i+j));
	}
	void add(float i,float j) {
		System.out.println("Add float value " + i+j);
	}
	void add(double i, double j) {
		System.out.println("Add double value "+ i+j);
	}
	
}

public class OverloadingDatatype {

	public static void main(String[] args) {
		Overload ob=new Overload();
		ob.add(3, 6);
		ob.add(4.6f,4.7f);
		ob.add(6.7, 6.9);

	}

}
