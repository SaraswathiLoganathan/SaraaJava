package june30;

public class ReverseSting {
	public static void main(String[] args) {
  String s="Computer is Fun";
  
  StringBuilder sb =new StringBuilder(s);
  System.out.println(sb.reverse());
  System.out.println(sb.append("India"));
}
}