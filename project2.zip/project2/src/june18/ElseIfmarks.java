package june18;

import java.util.Scanner;

public class ElseIfmarks {

	public static void main(String[] args) {
    
		
        try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter Mark");
			int marks = sc.nextInt();
		

        if(marks >=80 && marks <= 100){
            System.out.println("Grade A");
        }
            
            else if(marks >=  60 && marks <= 79){
            	 System.out.println("Grade B");
            }
            else if(marks >=  35 && marks <= 59){
           	 System.out.println("Grade C");
           }
            else if(marks >=  0 && marks <= 34){
              	 System.out.println("FAIL");
              }
            else if(marks >  100 || marks <0){
             	 System.out.println("Invalid input");
             }

}
        }
}