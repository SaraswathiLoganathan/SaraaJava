package june18;

import java.util.Scanner;

public class TernaryOperator {

	public static void main(String[] args) {
	
			int first, second,third,fourth,large;
			
			try (Scanner sc = new Scanner(System.in)) {
				System.out.println("Enter four numbers");
				first = sc.nextInt();
				second = sc.nextInt();
				third =sc.nextInt();
				fourth=sc.nextInt();
			}
			
			large = (first > second && first > third && first>fourth)?first:(second > third && second > fourth)?second:(third>fourth?third:fourth);

	     System.out.println("Largest of "+first+", "+second+" , "+third+" and " +fourth+" is "+large);
	     
	     
	}

}
