package june21;

public class OnetoTenWhileloop {

	public static void main(String[] args) {
		int i; 
        
         
        i=1; 
        while(i<=100){
            System.out.println(i);
            i++;

	}

}
}