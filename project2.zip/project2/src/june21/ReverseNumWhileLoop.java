package june21;

import java.util.Scanner;

class Reverse {
	int rev=0;
	int d;
	int num;
	void inputData() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number:");
		num=sc.nextInt();
	
	}
	
	void calculateData() {
		while(num>0) {
			d=num%10;
			System.out.print(d);
			rev=rev*10+d;
			num=num/10;
		}
	}
	void displayData() {
		System.out.println(rev);
		
	}
	
	
}

public class ReverseNumWhileLoop {

	public static void main(String[] args) {
		Reverse obj = new Reverse();
		obj.inputData();
		obj.calculateData();
		
		
	}

}
