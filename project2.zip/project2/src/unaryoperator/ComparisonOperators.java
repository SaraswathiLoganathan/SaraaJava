package unaryoperator;

public class ComparisonOperators {

	public static void main(String[] args) {
		int a=9, b=10;
		boolean c;
		c=b>a;
		System.out.println("c="+c);
		

	}

}
