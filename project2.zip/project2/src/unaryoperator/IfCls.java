package unaryoperator;

import java.util.Scanner;

public class IfCls {

	public static void main(String[] args) {
		String name;
		int age;
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter the name:");
			name=sc.nextLine();
			System.out.println("Enter the age:");
			age=sc.nextInt();
		}
		if(age>=18) {
			System.out.println("Your eligible for vote");
			
		}
		else {
			System.out.println("Your not eligible for vote");
		}
			
	}

}
