package unaryoperator;

public class UnaryOperator {

	public static void main(String[] args) {
		int i=3, j=1, k,z;
		++i;
		System.out.println("i="+i);
		i++;
		System.out.println("i="+i);
		
		//Express
		k=j++;
		System.out.println("k="+k);
		System.out.println("j="+j);
		
		k=++j;
		System.out.println("k="+k);
		System.out.println("j="+j);
		
		z=k++ + ++j;
		k=j++;
		System.out.println("z="+z);
		System.out.println("k="+k);
		System.out.println("j="+j);
	}

}
