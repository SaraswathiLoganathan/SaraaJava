package unaryoperator;

import java.util.Scanner;

public class UserInputData {

	public static void main(String[] args) {
		String name;
		int age;
		float fees;
		double amount;
		char gen;
		
		
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter the name:");
			name=sc.nextLine();
			System.out.println("Enter the age:");
			age=sc.nextInt();
			System.out.println("Enter the fees:");
			fees=sc.nextFloat();
			System.out.println("Enter the total amount:");
			amount=sc.nextDouble();
			System.out.println("Enter the gender m/f:");
			gen=sc.next().charAt(0);
		}
		
		System.out.println("Your details are");
		System.out.println("Name"+name);
		System.out.println("Age"+age);
		System.out.println("Fees"+fees);
		System.out.println("Amount"+amount);
		System.out.println("Gender"+gen);
		
	}

}
