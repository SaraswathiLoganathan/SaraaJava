package com.saras;

import static org.junit.Assert.*;

import org.junit.Test;

public class JunitTestDemo {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
